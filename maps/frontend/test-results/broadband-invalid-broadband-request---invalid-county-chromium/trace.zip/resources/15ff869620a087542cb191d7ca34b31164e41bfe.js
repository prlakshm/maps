import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Mapbox.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Map, { Layer, NavigationControl, Source } from "/node_modules/.vite/deps/react-map-gl.js?v=1e5b9a8a";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=1e5b9a8a"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useRef = __vite__cjsImport4_react["useRef"]; const useState = __vite__cjsImport4_react["useState"];
import { ACCESS_TOKEN } from "/src/private/api.ts";
import "/node_modules/mapbox-gl/dist/mapbox-gl.css";
import "/src/styles/map.css";
import { geoLayer, overlayData } from "/src/components/overlay.ts";
const coordinatesGeocoder = function(query) {
  const matches = query.match(/^[ ]*(?:Lat: )?(-?\d+\.?\d*)[, ]+(?:Lng: )?(-?\d+\.?\d*)[ ]*$/i);
  if (!matches) {
    return null;
  }
  function coordinateFeature(lng, lat) {
    return {
      center: [lng, lat],
      geometry: {
        type: "Point",
        coordinates: [lng, lat]
      },
      place_name: "Lat: " + lat + " Lng: " + lng,
      place_type: ["coordinate"],
      properties: {},
      type: "Feature"
    };
  }
  const coord1 = Number(matches[1]);
  const coord2 = Number(matches[2]);
  const geocodes = [];
  if (coord1 < -90 || coord1 > 90) {
    geocodes.push(coordinateFeature(coord1, coord2));
  }
  if (coord2 < -90 || coord2 > 90) {
    geocodes.push(coordinateFeature(coord2, coord1));
  }
  if (geocodes.length === 0) {
    geocodes.push(coordinateFeature(coord1, coord2));
    geocodes.push(coordinateFeature(coord2, coord1));
  }
  return geocodes;
};
const ProvidenceLatLong = {
  long: -71.418884,
  lat: 41.825226
};
const initialZoom = 10;
function Mapbox({
  coordinates,
  setCoordinates
}) {
  _s();
  const [viewState, setViewState] = useState({
    longitude: ProvidenceLatLong.long,
    latitude: ProvidenceLatLong.lat,
    zoom: initialZoom
  });
  const [overlay, setOverlay] = useState(void 0);
  const [inputLat, setInputLat] = useState("");
  const [inputLng, setInputLng] = useState("");
  const [highlightedCoordinates, setHighlightedCoordinates] = useState(void 0);
  const latitudeInputRef = useRef(null);
  const mapRef = useRef(null);
  useEffect(() => {
    setOverlay(overlayData());
  }, []);
  useEffect(() => {
    if (coordinates) {
      const coordinateFeatures = coordinates.map(([lng, lat]) => ({
        type: "Feature",
        properties: {},
        geometry: {
          type: "Point",
          coordinates: [lng, lat]
        }
      }));
      setHighlightedCoordinates({
        type: "FeatureCollection",
        features: coordinateFeatures
      });
    }
  }, [coordinates]);
  useEffect(() => {
    if (coordinates) {
      const coordinateFeatures = coordinates.map(([lng, lat]) => ({
        type: "Feature",
        properties: {},
        geometry: {
          type: "Point",
          coordinates: [lng, lat]
        }
      }));
      setHighlightedCoordinates({
        type: "FeatureCollection",
        features: coordinateFeatures
      });
      const bounds = coordinates.reduce((bbox, [lng, lat]) => {
        return [[Math.min(bbox[0][0], lng), Math.min(bbox[0][1], lat)], [Math.max(bbox[1][0], lng), Math.max(bbox[1][1], lat)]];
      }, [
        [180, 90],
        // Initial max values
        [-180, -90]
        // Initial min values
      ]);
      if (mapRef.current) {
        const map = mapRef.current;
        map.fitBounds(bounds, {
          padding: 40,
          // Optional padding
          maxZoom: 15
          // Adjust the maximum zoom level if needed
        });
      }
    }
  }, [coordinates]);
  function onMapClick(e) {
    console.log(e);
    console.log(e.lngLat.lat);
    console.log(e.lngLat.lng);
  }
  function handleGeocode() {
    const lat = parseFloat(inputLat);
    const lng = parseFloat(inputLng);
    if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      alert("Invalid latitude or longitude values. Please enter valid coordinates.");
      return;
    }
    const geocodedFeature = coordinatesGeocoder(`${lng}, ${lat}`);
    if (geocodedFeature) {
      setViewState({
        longitude: lng,
        latitude: lat,
        zoom: initialZoom
      });
    } else {
      alert("Geocoding failed. Please check your input values.");
    }
  }
  function handleEnterPress(e) {
    if (e.key === "Enter") {
      handleGeocode();
    }
  }
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === "q" && e.ctrlKey) {
        if (latitudeInputRef.current) {
          latitudeInputRef.current.focus();
        }
      }
    };
    document.addEventListener("keydown", handleKeyPress);
    return () => {
      document.removeEventListener("keydown", handleKeyPress);
    };
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "geocode-container", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "input-label", children: "Latitude:" }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 228,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "text", className: "input-field", value: inputLat, onChange: (e) => setInputLat(e.target.value), placeholder: "Enter latitude", onKeyDown: handleEnterPress, ref: latitudeInputRef }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 229,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { className: "input-label", children: " Longitude:" }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 230,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "text", className: "input-field", value: inputLng, onChange: (e) => setInputLng(e.target.value), placeholder: "Enter longitude", onKeyDown: handleEnterPress }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 231,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "geocode-button", onClick: handleGeocode, children: "Geocode" }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 232,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
      lineNumber: 227,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "map-container", "data-lat": viewState.latitude, "data-long": viewState.longitude, "data-zoom": viewState.zoom, children: /* @__PURE__ */ jsxDEV(Map, { ref: mapRef, mapboxAccessToken: ACCESS_TOKEN, longitude: viewState.longitude, latitude: viewState.latitude, zoom: viewState.zoom, onMove: (ev) => setViewState(ev.viewState), style: {
      width: "100%",
      height: "96vh"
    }, mapStyle: "mapbox://styles/mapbox/outdoors-v12", onClick: onMapClick, children: [
      /* @__PURE__ */ jsxDEV(NavigationControl, { showZoom: true }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 243,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Source, { id: "geo_data", type: "geojson", data: overlay, children: /* @__PURE__ */ jsxDEV(Layer, { id: geoLayer.id, type: geoLayer.type, paint: geoLayer.paint }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 247,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 246,
        columnNumber: 11
      }, this),
      highlightedCoordinates && /* @__PURE__ */ jsxDEV(Source, { id: "highlighted_coordinates", type: "geojson", data: highlightedCoordinates, children: /* @__PURE__ */ jsxDEV(Layer, { id: "highlighted_coordinates_layer", type: "circle", paint: {
        "circle-radius": 8,
        "circle-color": "#FF4E40"
        // red color for highlights
      } }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 252,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
        lineNumber: 251,
        columnNumber: 38
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
      lineNumber: 239,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
      lineNumber: 238,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx",
    lineNumber: 225,
    columnNumber: 10
  }, this);
}
_s(Mapbox, "G+vyTXzhb+n9/rW2dRqpNG/TQhg=");
_c = Mapbox;
export default Mapbox;
var _c;
$RefreshReg$(_c, "Mapbox");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/Mapbox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaVJROzs7Ozs7Ozs7Ozs7Ozs7O0FBaFJSLE9BQU9BLE9BQ0xDLE9BR0FDLG1CQUNBQyxjQUVLO0FBQ1AsU0FHRUMsV0FDQUMsUUFDQUMsZ0JBQ0s7QUFHUCxTQUFTQyxvQkFBb0I7QUFDN0IsT0FBTztBQUNQLE9BQU87QUFDUCxTQUFTQyxVQUFVQyxtQkFBbUI7QUFrQnRDLE1BQU1DLHNCQUFzQixTQUFVQyxPQUFlO0FBRW5ELFFBQU1DLFVBQVVELE1BQU1FLE1BQ3BCLGdFQUFnRTtBQUVsRSxNQUFJLENBQUNELFNBQVM7QUFDWixXQUFPO0FBQUEsRUFDVDtBQUdBLFdBQVNFLGtCQUFrQkMsS0FBYUMsS0FBYTtBQUNuRCxXQUFPO0FBQUEsTUFDTEMsUUFBUSxDQUFDRixLQUFLQyxHQUFHO0FBQUEsTUFDakJFLFVBQVU7QUFBQSxRQUNSQyxNQUFNO0FBQUEsUUFDTkMsYUFBYSxDQUFDTCxLQUFLQyxHQUFHO0FBQUEsTUFDeEI7QUFBQSxNQUNBSyxZQUFZLFVBQVVMLE1BQU0sV0FBV0Q7QUFBQUEsTUFDdkNPLFlBQVksQ0FBQyxZQUFZO0FBQUEsTUFDekJDLFlBQVksQ0FBQztBQUFBLE1BQ2JKLE1BQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUVBLFFBQU1LLFNBQVNDLE9BQU9iLFFBQVEsQ0FBQyxDQUFDO0FBQ2hDLFFBQU1jLFNBQVNELE9BQU9iLFFBQVEsQ0FBQyxDQUFDO0FBQ2hDLFFBQU1lLFdBQVc7QUFHakIsTUFBSUgsU0FBUyxPQUFPQSxTQUFTLElBQUk7QUFFL0JHLGFBQVNDLEtBQUtkLGtCQUFrQlUsUUFBUUUsTUFBTSxDQUFDO0FBQUEsRUFDakQ7QUFFQSxNQUFJQSxTQUFTLE9BQU9BLFNBQVMsSUFBSTtBQUUvQkMsYUFBU0MsS0FBS2Qsa0JBQWtCWSxRQUFRRixNQUFNLENBQUM7QUFBQSxFQUNqRDtBQUVBLE1BQUlHLFNBQVNFLFdBQVcsR0FBRztBQUV6QkYsYUFBU0MsS0FBS2Qsa0JBQWtCVSxRQUFRRSxNQUFNLENBQUM7QUFDL0NDLGFBQVNDLEtBQUtkLGtCQUFrQlksUUFBUUYsTUFBTSxDQUFDO0FBQUEsRUFDakQ7QUFFQSxTQUFPRztBQUNUO0FBR0EsTUFBTUcsb0JBQW9CO0FBQUEsRUFDeEJDLE1BQU07QUFBQSxFQUNOZixLQUFLO0FBQ1A7QUFFQSxNQUFNZ0IsY0FBYztBQUdwQixTQUFTQyxPQUFPO0FBQUEsRUFBRWI7QUFBQUEsRUFBYWM7QUFBNEIsR0FBRztBQUFBQztBQUU1RCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSS9CLFNBQVM7QUFBQSxJQUN6Q2dDLFdBQVdSLGtCQUFrQkM7QUFBQUEsSUFDN0JRLFVBQVVULGtCQUFrQmQ7QUFBQUEsSUFDNUJ3QixNQUFNUjtBQUFBQSxFQUNSLENBQUM7QUFHRCxRQUFNLENBQUNTLFNBQVNDLFVBQVUsSUFBSXBDLFNBQzVCcUMsTUFBUztBQUlYLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJdkMsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3dDLFVBQVVDLFdBQVcsSUFBSXpDLFNBQVMsRUFBRTtBQUczQyxRQUFNLENBQUMwQyx3QkFBd0JDLHlCQUF5QixJQUFJM0MsU0FFMURxQyxNQUFTO0FBR1gsUUFBTU8sbUJBQW1CN0MsT0FBZ0MsSUFBSTtBQUU3RCxRQUFNOEMsU0FBMEM5QyxPQUFzQixJQUFJO0FBRzFFRCxZQUFVLE1BQU07QUFDZHNDLGVBQVdqQyxZQUFXLENBQUU7QUFBQSxFQUMxQixHQUFHLEVBQUU7QUFHTEwsWUFBVSxNQUFNO0FBQ2QsUUFBSWdCLGFBQWE7QUFDZixZQUFNZ0MscUJBQXdDaEMsWUFBWWlDLElBQ3hELENBQUMsQ0FBQ3RDLEtBQUtDLEdBQUcsT0FBTztBQUFBLFFBQ2ZHLE1BQU07QUFBQSxRQUNOSSxZQUFZLENBQUM7QUFBQSxRQUNiTCxVQUFVO0FBQUEsVUFDUkMsTUFBTTtBQUFBLFVBQ05DLGFBQWEsQ0FBQ0wsS0FBS0MsR0FBRztBQUFBLFFBQ3hCO0FBQUEsTUFDRixFQUFFO0FBR0ppQyxnQ0FBMEI7QUFBQSxRQUN4QjlCLE1BQU07QUFBQSxRQUNObUMsVUFBVUY7QUFBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsR0FBRyxDQUFDaEMsV0FBVyxDQUFDO0FBRWhCaEIsWUFBVSxNQUFNO0FBQ2QsUUFBSWdCLGFBQWE7QUFDZixZQUFNZ0MscUJBQXdDaEMsWUFBWWlDLElBQ3hELENBQUMsQ0FBQ3RDLEtBQUtDLEdBQUcsT0FBTztBQUFBLFFBQ2ZHLE1BQU07QUFBQSxRQUNOSSxZQUFZLENBQUM7QUFBQSxRQUNiTCxVQUFVO0FBQUEsVUFDUkMsTUFBTTtBQUFBLFVBQ05DLGFBQWEsQ0FBQ0wsS0FBS0MsR0FBRztBQUFBLFFBQ3hCO0FBQUEsTUFDRixFQUFFO0FBR0ppQyxnQ0FBMEI7QUFBQSxRQUN4QjlCLE1BQU07QUFBQSxRQUNObUMsVUFBVUY7QUFBQUEsTUFDWixDQUFDO0FBR0QsWUFBTUcsU0FBMkJuQyxZQUFZb0MsT0FDM0MsQ0FBQ0MsTUFBTSxDQUFDMUMsS0FBS0MsR0FBRyxNQUFNO0FBQ3BCLGVBQU8sQ0FDTCxDQUFDMEMsS0FBS0MsSUFBSUYsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHMUMsR0FBRyxHQUFHMkMsS0FBS0MsSUFBSUYsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHekMsR0FBRyxDQUFDLEdBQ3JELENBQUMwQyxLQUFLRSxJQUFJSCxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcxQyxHQUFHLEdBQUcyQyxLQUFLRSxJQUFJSCxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUd6QyxHQUFHLENBQUMsQ0FBQztBQUFBLE1BRTFELEdBQ0E7QUFBQSxRQUNFLENBQUMsS0FBSyxFQUFFO0FBQUE7QUFBQSxRQUNSLENBQUMsTUFBTSxHQUFHO0FBQUE7QUFBQSxNQUFHLENBQ2Q7QUFHSCxVQUFJbUMsT0FBT1UsU0FBUztBQUNsQixjQUFNUixNQUFNRixPQUFPVTtBQUduQlIsWUFBSVMsVUFBVVAsUUFBUTtBQUFBLFVBQ3BCUSxTQUFTO0FBQUE7QUFBQSxVQUNUQyxTQUFTO0FBQUE7QUFBQSxRQUNYLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDNUMsV0FBVyxDQUFDO0FBR2hCLFdBQVM2QyxXQUFXQyxHQUF1QjtBQUN6Q0MsWUFBUUMsSUFBSUYsQ0FBQztBQUNiQyxZQUFRQyxJQUFJRixFQUFFRyxPQUFPckQsR0FBRztBQUN4Qm1ELFlBQVFDLElBQUlGLEVBQUVHLE9BQU90RCxHQUFHO0FBQUEsRUFDMUI7QUFHQSxXQUFTdUQsZ0JBQWdCO0FBRXZCLFVBQU10RCxNQUFNdUQsV0FBVzNCLFFBQVE7QUFDL0IsVUFBTTdCLE1BQU13RCxXQUFXekIsUUFBUTtBQUcvQixRQUNFMEIsTUFBTXhELEdBQUcsS0FDVHdELE1BQU16RCxHQUFHLEtBQ1RDLE1BQU0sT0FDTkEsTUFBTSxNQUNORCxNQUFNLFFBQ05BLE1BQU0sS0FDTjtBQUNBMEQsWUFDRSx1RUFBdUU7QUFFekU7QUFBQSxJQUNGO0FBR0EsVUFBTUMsa0JBQWtCaEUsb0JBQXFCLEdBQUVLLFFBQVFDLEtBQUs7QUFFNUQsUUFBSTBELGlCQUFpQjtBQUVuQnJDLG1CQUFhO0FBQUEsUUFDWEMsV0FBV3ZCO0FBQUFBLFFBQ1h3QixVQUFVdkI7QUFBQUEsUUFDVndCLE1BQU1SO0FBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMeUMsWUFBTSxtREFBbUQ7QUFBQSxJQUMzRDtBQUFBLEVBQ0Y7QUFPQSxXQUFTRSxpQkFBaUJULEdBQXdCO0FBQ2hELFFBQUlBLEVBQUVVLFFBQVEsU0FBUztBQUNyQk4sb0JBQWE7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUtBbEUsWUFBVSxNQUFNO0FBQ2QsVUFBTXlFLGlCQUFpQkEsQ0FBQ1gsTUFBcUI7QUFDM0MsVUFBSUEsRUFBRVUsUUFBUSxPQUFPVixFQUFFWSxTQUFTO0FBRTlCLFlBQUk1QixpQkFBaUJXLFNBQVM7QUFDNUJYLDJCQUFpQlcsUUFBUWtCLE1BQUs7QUFBQSxRQUNoQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUFDLGFBQVNDLGlCQUFpQixXQUFXSixjQUFjO0FBRW5ELFdBQU8sTUFBTTtBQUNYRyxlQUFTRSxvQkFBb0IsV0FBV0wsY0FBYztBQUFBLElBQ3hEO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFJTCxTQUNFLHVCQUFDLFNBRUM7QUFBQSwyQkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSw2QkFBQyxXQUFNLFdBQVUsZUFBYyx5QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QztBQUFBLE1BQ3hDLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLFdBQVUsZUFDVixPQUFPakMsVUFDUCxVQUFXc0IsT0FBTXJCLFlBQVlxQixFQUFFaUIsT0FBT0MsS0FBSyxHQUMzQyxhQUFZLGtCQUNaLFdBQVdULGtCQUNYLEtBQUt6QixvQkFQUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT3dCO0FBQUEsTUFFeEIsdUJBQUMsV0FBTSxXQUFVLGVBQWMsMkJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEM7QUFBQSxNQUMxQyx1QkFBQyxXQUNDLE1BQUssUUFDTCxXQUFVLGVBQ1YsT0FBT0osVUFDUCxVQUFXb0IsT0FBTW5CLFlBQVltQixFQUFFaUIsT0FBT0MsS0FBSyxHQUMzQyxhQUFZLG1CQUNaLFdBQVdULG9CQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNOEI7QUFBQSxNQUU5Qix1QkFBQyxZQUFPLFdBQVUsa0JBQWlCLFNBQVNMLGVBQWUsdUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUdBLHVCQUFDLFNBQ0MsV0FBVSxpQkFDVixZQUFVbEMsVUFBVUcsVUFDcEIsYUFBV0gsVUFBVUUsV0FDckIsYUFBV0YsVUFBVUksTUFFckIsaUNBQUMsT0FDQyxLQUFLVyxRQUNMLG1CQUFtQjVDLGNBQ25CLFdBQVc2QixVQUFVRSxXQUNyQixVQUFVRixVQUFVRyxVQUNwQixNQUFNSCxVQUFVSSxNQUNoQixRQUFRLENBQUM2QyxPQUE2QmhELGFBQWFnRCxHQUFHakQsU0FBUyxHQUMvRCxPQUFPO0FBQUEsTUFBRWtELE9BQU87QUFBQSxNQUFRQyxRQUFRO0FBQUEsSUFBTyxHQUN2QyxVQUFVLHVDQUNWLFNBQVN0QixZQUVUO0FBQUEsNkJBQUMscUJBQWtCLFVBQVUsUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BR2xDLHVCQUFDLFVBQU8sSUFBRyxZQUFXLE1BQUssV0FBVSxNQUFNeEIsU0FDekMsaUNBQUMsU0FDQyxJQUFJakMsU0FBU2dGLElBQ2IsTUFBTWhGLFNBQVNXLE1BQ2YsT0FBT1gsU0FBU2lGLFNBSGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHd0IsS0FKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFHQ3pDLDBCQUNDLHVCQUFDLFVBQ0MsSUFBRywyQkFDSCxNQUFLLFdBQ0wsTUFBTUEsd0JBRU4saUNBQUMsU0FDQyxJQUFHLGlDQUNILE1BQUssVUFDTCxPQUFPO0FBQUEsUUFDTCxpQkFBaUI7QUFBQSxRQUNqQixnQkFBZ0I7QUFBQTtBQUFBLE1BQ2xCLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1JLEtBWE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0FyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVDQSxLQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOENBO0FBQUEsT0ExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJFQTtBQUVKO0FBRUFiLEdBN1BTRixRQUFNO0FBQUF5RCxLQUFOekQ7QUE4UFQsZUFBZUE7QUFBTztBQUFBMEQiLCJuYW1lcyI6WyJNYXAiLCJMYXllciIsIk5hdmlnYXRpb25Db250cm9sIiwiU291cmNlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJBQ0NFU1NfVE9LRU4iLCJnZW9MYXllciIsIm92ZXJsYXlEYXRhIiwiY29vcmRpbmF0ZXNHZW9jb2RlciIsInF1ZXJ5IiwibWF0Y2hlcyIsIm1hdGNoIiwiY29vcmRpbmF0ZUZlYXR1cmUiLCJsbmciLCJsYXQiLCJjZW50ZXIiLCJnZW9tZXRyeSIsInR5cGUiLCJjb29yZGluYXRlcyIsInBsYWNlX25hbWUiLCJwbGFjZV90eXBlIiwicHJvcGVydGllcyIsImNvb3JkMSIsIk51bWJlciIsImNvb3JkMiIsImdlb2NvZGVzIiwicHVzaCIsImxlbmd0aCIsIlByb3ZpZGVuY2VMYXRMb25nIiwibG9uZyIsImluaXRpYWxab29tIiwiTWFwYm94Iiwic2V0Q29vcmRpbmF0ZXMiLCJfcyIsInZpZXdTdGF0ZSIsInNldFZpZXdTdGF0ZSIsImxvbmdpdHVkZSIsImxhdGl0dWRlIiwiem9vbSIsIm92ZXJsYXkiLCJzZXRPdmVybGF5IiwidW5kZWZpbmVkIiwiaW5wdXRMYXQiLCJzZXRJbnB1dExhdCIsImlucHV0TG5nIiwic2V0SW5wdXRMbmciLCJoaWdobGlnaHRlZENvb3JkaW5hdGVzIiwic2V0SGlnaGxpZ2h0ZWRDb29yZGluYXRlcyIsImxhdGl0dWRlSW5wdXRSZWYiLCJtYXBSZWYiLCJjb29yZGluYXRlRmVhdHVyZXMiLCJtYXAiLCJmZWF0dXJlcyIsImJvdW5kcyIsInJlZHVjZSIsImJib3giLCJNYXRoIiwibWluIiwibWF4IiwiY3VycmVudCIsImZpdEJvdW5kcyIsInBhZGRpbmciLCJtYXhab29tIiwib25NYXBDbGljayIsImUiLCJjb25zb2xlIiwibG9nIiwibG5nTGF0IiwiaGFuZGxlR2VvY29kZSIsInBhcnNlRmxvYXQiLCJpc05hTiIsImFsZXJ0IiwiZ2VvY29kZWRGZWF0dXJlIiwiaGFuZGxlRW50ZXJQcmVzcyIsImtleSIsImhhbmRsZUtleVByZXNzIiwiY3RybEtleSIsImZvY3VzIiwiZG9jdW1lbnQiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsInRhcmdldCIsInZhbHVlIiwiZXYiLCJ3aWR0aCIsImhlaWdodCIsImlkIiwicGFpbnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1hcGJveC50c3giXSwiZmlsZSI6IkM6L1VzZXJzL3ByYW5hL0RvY3VtZW50cy9HaXRIdWIvbWFwcy1wcmxha3NobS10Ym9uYXMvbWFwcy9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9NYXBib3gudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0IG5lY2Vzc2FyeSBsaWJyYXJpZXMgYW5kIGRlcGVuZGVuY2llc1xyXG5pbXBvcnQgTWFwLCB7XHJcbiAgTGF5ZXIsXHJcbiAgTG5nTGF0Qm91bmRzTGlrZSxcclxuICBNYXBMYXllck1vdXNlRXZlbnQsXHJcbiAgTmF2aWdhdGlvbkNvbnRyb2wsXHJcbiAgU291cmNlLFxyXG4gIFZpZXdTdGF0ZUNoYW5nZUV2ZW50LFxyXG59IGZyb20gXCJyZWFjdC1tYXAtZ2xcIjtcclxuaW1wb3J0IFJlYWN0LCB7XHJcbiAgRGlzcGF0Y2gsXHJcbiAgU2V0U3RhdGVBY3Rpb24sXHJcbiAgdXNlRWZmZWN0LFxyXG4gIHVzZVJlZixcclxuICB1c2VTdGF0ZSxcclxufSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTXV0YWJsZVJlZk9iamVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBNYXBSZWYgfSBmcm9tIFwicmVhY3QtbWFwLWdsXCI7XHJcbmltcG9ydCB7IEFDQ0VTU19UT0tFTiB9IGZyb20gXCIuLi9wcml2YXRlL2FwaS5qc1wiOyAvLyBJbXBvcnQgYW4gQVBJIGFjY2VzcyB0b2tlblxyXG5pbXBvcnQgXCJtYXBib3gtZ2wvZGlzdC9tYXBib3gtZ2wuY3NzXCI7IC8vIEltcG9ydCBNYXBib3ggQ1NTXHJcbmltcG9ydCBcIi4uL3N0eWxlcy9tYXAuY3NzXCI7IC8vIEltcG9ydCBjdXN0b20gc3R5bGVzXHJcbmltcG9ydCB7IGdlb0xheWVyLCBvdmVybGF5RGF0YSB9IGZyb20gXCIuL292ZXJsYXkuanNcIjsgLy8gSW1wb3J0IGN1c3RvbSBvdmVybGF5IGRhdGEgYW5kIHNldHRpbmdzXHJcblxyXG4vLyBEZWZpbmUgaW50ZXJmYWNlcyBmb3IgTWFwYm94IGZlYXR1cmVzIGFuZCByZXNwb25zZXNcclxuaW50ZXJmYWNlIE1hcGJveEZlYXR1cmUge1xyXG4gIHBsYWNlX3R5cGU6IHN0cmluZ1tdO1xyXG4gIHRleHQ6IHN0cmluZztcclxufVxyXG5cclxuaW50ZXJmYWNlIE1hcGJveFJlc3BvbnNlIHtcclxuICBmZWF0dXJlczogTWFwYm94RmVhdHVyZVtdO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgTWFwQm94UHJvcHMge1xyXG4gIGNvb3JkaW5hdGVzOiBudW1iZXJbXVtdO1xyXG4gIHNldENvb3JkaW5hdGVzOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxudW1iZXJbXVtdPj47XHJcbn1cclxuXHJcbi8vIEZ1bmN0aW9uIHRvIGdlb2NvZGUgY29vcmRpbmF0ZXNcclxuY29uc3QgY29vcmRpbmF0ZXNHZW9jb2RlciA9IGZ1bmN0aW9uIChxdWVyeTogc3RyaW5nKSB7XHJcbiAgLy8gTWF0Y2ggYW55dGhpbmcgd2hpY2ggbG9va3MgbGlrZSBkZWNpbWFsIGRlZ3JlZXMgY29vcmRpbmF0ZSBwYWlyXHJcbiAgY29uc3QgbWF0Y2hlcyA9IHF1ZXJ5Lm1hdGNoKFxyXG4gICAgL15bIF0qKD86TGF0OiApPygtP1xcZCtcXC4/XFxkKilbLCBdKyg/OkxuZzogKT8oLT9cXGQrXFwuP1xcZCopWyBdKiQvaVxyXG4gICk7XHJcbiAgaWYgKCFtYXRjaGVzKSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIC8vIERlZmluZSBhIGNvb3JkaW5hdGUgZmVhdHVyZSBiYXNlZCBvbiBsYXRpdHVkZSBhbmQgbG9uZ2l0dWRlXHJcbiAgZnVuY3Rpb24gY29vcmRpbmF0ZUZlYXR1cmUobG5nOiBudW1iZXIsIGxhdDogbnVtYmVyKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBjZW50ZXI6IFtsbmcsIGxhdF0sXHJcbiAgICAgIGdlb21ldHJ5OiB7XHJcbiAgICAgICAgdHlwZTogXCJQb2ludFwiLFxyXG4gICAgICAgIGNvb3JkaW5hdGVzOiBbbG5nLCBsYXRdLFxyXG4gICAgICB9LFxyXG4gICAgICBwbGFjZV9uYW1lOiBcIkxhdDogXCIgKyBsYXQgKyBcIiBMbmc6IFwiICsgbG5nLFxyXG4gICAgICBwbGFjZV90eXBlOiBbXCJjb29yZGluYXRlXCJdLFxyXG4gICAgICBwcm9wZXJ0aWVzOiB7fSxcclxuICAgICAgdHlwZTogXCJGZWF0dXJlXCIsXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgY29uc3QgY29vcmQxID0gTnVtYmVyKG1hdGNoZXNbMV0pO1xyXG4gIGNvbnN0IGNvb3JkMiA9IE51bWJlcihtYXRjaGVzWzJdKTtcclxuICBjb25zdCBnZW9jb2RlcyA9IFtdO1xyXG5cclxuICAvLyBDaGVjayBpZiBjb29yZGluYXRlIHZhbHVlcyBhcmUgdmFsaWQgKGxhdGl0dWRlIHNob3VsZCBiZSAtOTAgdG8gOTAsIGxvbmdpdHVkZSAtMTgwIHRvIDE4MClcclxuICBpZiAoY29vcmQxIDwgLTkwIHx8IGNvb3JkMSA+IDkwKSB7XHJcbiAgICAvLyBJZiB0aGUgZmlyc3QgdmFsdWUgaXMgb3V0c2lkZSB2YWxpZCBsYXRpdHVkZSByYW5nZSwgaXQgbXVzdCBiZSBhIGxvbmdpdHVkZVxyXG4gICAgZ2VvY29kZXMucHVzaChjb29yZGluYXRlRmVhdHVyZShjb29yZDEsIGNvb3JkMikpO1xyXG4gIH1cclxuXHJcbiAgaWYgKGNvb3JkMiA8IC05MCB8fCBjb29yZDIgPiA5MCkge1xyXG4gICAgLy8gSWYgdGhlIHNlY29uZCB2YWx1ZSBpcyBvdXRzaWRlIHZhbGlkIGxhdGl0dWRlIHJhbmdlLCBpdCBtdXN0IGJlIGEgbG9uZ2l0dWRlXHJcbiAgICBnZW9jb2Rlcy5wdXNoKGNvb3JkaW5hdGVGZWF0dXJlKGNvb3JkMiwgY29vcmQxKSk7XHJcbiAgfVxyXG5cclxuICBpZiAoZ2VvY29kZXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAvLyBJZiBuZWl0aGVyIHZhbHVlIGlzIG91dHNpZGUgdmFsaWQgbGF0aXR1ZGUgcmFuZ2UsIGl0IGNvdWxkIGJlIGVpdGhlciBvcmRlciAobG5nLCBsYXQpIG9yIChsYXQsIGxuZylcclxuICAgIGdlb2NvZGVzLnB1c2goY29vcmRpbmF0ZUZlYXR1cmUoY29vcmQxLCBjb29yZDIpKTsgLy8gQXNzdW1lIChsbmcsIGxhdClcclxuICAgIGdlb2NvZGVzLnB1c2goY29vcmRpbmF0ZUZlYXR1cmUoY29vcmQyLCBjb29yZDEpKTsgLy8gQXNzdW1lIChsYXQsIGxuZylcclxuICB9XHJcblxyXG4gIHJldHVybiBnZW9jb2RlcztcclxufTtcclxuXHJcbi8vIEluaXRpYWwgY29vcmRpbmF0ZXMgZm9yIFByb3ZpZGVuY2UsIFJob2RlIElzbGFuZFxyXG5jb25zdCBQcm92aWRlbmNlTGF0TG9uZyA9IHtcclxuICBsb25nOiAtNzEuNDE4ODg0LFxyXG4gIGxhdDogNDEuODI1MjI2LFxyXG59O1xyXG5cclxuY29uc3QgaW5pdGlhbFpvb20gPSAxMDtcclxuXHJcbi8vIE1haW4gTWFwYm94IGNvbXBvbmVudFxyXG5mdW5jdGlvbiBNYXBib3goeyBjb29yZGluYXRlcywgc2V0Q29vcmRpbmF0ZXMgfTogTWFwQm94UHJvcHMpIHtcclxuICAvLyBTdGF0ZSBmb3IgbWFuYWdpbmcgdGhlIG1hcCB2aWV3XHJcbiAgY29uc3QgW3ZpZXdTdGF0ZSwgc2V0Vmlld1N0YXRlXSA9IHVzZVN0YXRlKHtcclxuICAgIGxvbmdpdHVkZTogUHJvdmlkZW5jZUxhdExvbmcubG9uZyxcclxuICAgIGxhdGl0dWRlOiBQcm92aWRlbmNlTGF0TG9uZy5sYXQsXHJcbiAgICB6b29tOiBpbml0aWFsWm9vbSxcclxuICB9KTtcclxuXHJcbiAgLy8gU3RhdGUgZm9yIG1hbmFnaW5nIHRoZSBvdmVybGF5IGRhdGFcclxuICBjb25zdCBbb3ZlcmxheSwgc2V0T3ZlcmxheV0gPSB1c2VTdGF0ZTxHZW9KU09OLkZlYXR1cmVDb2xsZWN0aW9uIHwgdW5kZWZpbmVkPihcclxuICAgIHVuZGVmaW5lZFxyXG4gICk7XHJcblxyXG4gIC8vIFN0YXRlIGZvciBtYW5hZ2luZyBsYXRpdHVkZSBhbmQgbG9uZ2l0dWRlIGlucHV0c1xyXG4gIGNvbnN0IFtpbnB1dExhdCwgc2V0SW5wdXRMYXRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lucHV0TG5nLCBzZXRJbnB1dExuZ10gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgLy8gU3RhdGUgZm9yIG1hbmFnaW5nIHRoZSBoaWdobGlnaHRlZCBjb29yZGluYXRlc1xyXG4gIGNvbnN0IFtoaWdobGlnaHRlZENvb3JkaW5hdGVzLCBzZXRIaWdobGlnaHRlZENvb3JkaW5hdGVzXSA9IHVzZVN0YXRlPFxyXG4gICAgR2VvSlNPTi5GZWF0dXJlQ29sbGVjdGlvbiB8IHVuZGVmaW5lZFxyXG4gID4odW5kZWZpbmVkKTtcclxuXHJcbiAgLy8gQ3JlYXRlIGEgcmVmIGZvciB0aGUgbG9uZ2l0dWRlIGlucHV0IGVsZW1lbnRcclxuICBjb25zdCBsYXRpdHVkZUlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3QgbWFwUmVmOiBNdXRhYmxlUmVmT2JqZWN0PE1hcFJlZiB8IG51bGw+ID0gdXNlUmVmPE1hcFJlZiB8IG51bGw+KG51bGwpO1xyXG5cclxuICAvLyBMb2FkIHRoZSBvdmVybGF5IGRhdGEgd2hlbiB0aGUgY29tcG9uZW50IG1vdW50c1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRPdmVybGF5KG92ZXJsYXlEYXRhKCkpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gVXBkYXRlIGhpZ2hsaWdodGVkIGNvb3JkaW5hdGVzIHdoZW4gdGhlIGNvb3JkaW5hdGVzIHByb3AgY2hhbmdlc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoY29vcmRpbmF0ZXMpIHtcclxuICAgICAgY29uc3QgY29vcmRpbmF0ZUZlYXR1cmVzOiBHZW9KU09OLkZlYXR1cmVbXSA9IGNvb3JkaW5hdGVzLm1hcChcclxuICAgICAgICAoW2xuZywgbGF0XSkgPT4gKHtcclxuICAgICAgICAgIHR5cGU6IFwiRmVhdHVyZVwiLFxyXG4gICAgICAgICAgcHJvcGVydGllczoge30sXHJcbiAgICAgICAgICBnZW9tZXRyeToge1xyXG4gICAgICAgICAgICB0eXBlOiBcIlBvaW50XCIsXHJcbiAgICAgICAgICAgIGNvb3JkaW5hdGVzOiBbbG5nLCBsYXRdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KVxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0SGlnaGxpZ2h0ZWRDb29yZGluYXRlcyh7XHJcbiAgICAgICAgdHlwZTogXCJGZWF0dXJlQ29sbGVjdGlvblwiLFxyXG4gICAgICAgIGZlYXR1cmVzOiBjb29yZGluYXRlRmVhdHVyZXMsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH0sIFtjb29yZGluYXRlc10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGNvb3JkaW5hdGVzKSB7XHJcbiAgICAgIGNvbnN0IGNvb3JkaW5hdGVGZWF0dXJlczogR2VvSlNPTi5GZWF0dXJlW10gPSBjb29yZGluYXRlcy5tYXAoXHJcbiAgICAgICAgKFtsbmcsIGxhdF0pID0+ICh7XHJcbiAgICAgICAgICB0eXBlOiBcIkZlYXR1cmVcIixcclxuICAgICAgICAgIHByb3BlcnRpZXM6IHt9LFxyXG4gICAgICAgICAgZ2VvbWV0cnk6IHtcclxuICAgICAgICAgICAgdHlwZTogXCJQb2ludFwiLFxyXG4gICAgICAgICAgICBjb29yZGluYXRlczogW2xuZywgbGF0XSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSlcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldEhpZ2hsaWdodGVkQ29vcmRpbmF0ZXMoe1xyXG4gICAgICAgIHR5cGU6IFwiRmVhdHVyZUNvbGxlY3Rpb25cIixcclxuICAgICAgICBmZWF0dXJlczogY29vcmRpbmF0ZUZlYXR1cmVzLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIENhbGN1bGF0ZSB0aGUgYm91bmRpbmcgYm94IGZvciB0aGUgaGlnaGxpZ2h0ZWQgY29vcmRpbmF0ZXNcclxuICAgICAgY29uc3QgYm91bmRzOiBMbmdMYXRCb3VuZHNMaWtlID0gY29vcmRpbmF0ZXMucmVkdWNlKFxyXG4gICAgICAgIChiYm94LCBbbG5nLCBsYXRdKSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gW1xyXG4gICAgICAgICAgICBbTWF0aC5taW4oYmJveFswXVswXSwgbG5nKSwgTWF0aC5taW4oYmJveFswXVsxXSwgbGF0KV0sXHJcbiAgICAgICAgICAgIFtNYXRoLm1heChiYm94WzFdWzBdLCBsbmcpLCBNYXRoLm1heChiYm94WzFdWzFdLCBsYXQpXSxcclxuICAgICAgICAgIF07XHJcbiAgICAgICAgfSxcclxuICAgICAgICBbXHJcbiAgICAgICAgICBbMTgwLCA5MF0sIC8vIEluaXRpYWwgbWF4IHZhbHVlc1xyXG4gICAgICAgICAgWy0xODAsIC05MF0sIC8vIEluaXRpYWwgbWluIHZhbHVlc1xyXG4gICAgICAgIF1cclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChtYXBSZWYuY3VycmVudCkge1xyXG4gICAgICAgIGNvbnN0IG1hcCA9IG1hcFJlZi5jdXJyZW50O1xyXG5cclxuICAgICAgICAvLyBVc2UgdGhlIGZpdEJvdW5kcyBtZXRob2QgdG8gc2V0IHRoZSBtYXAncyB2aWV3cG9ydFxyXG4gICAgICAgIG1hcC5maXRCb3VuZHMoYm91bmRzLCB7XHJcbiAgICAgICAgICBwYWRkaW5nOiA0MCwgLy8gT3B0aW9uYWwgcGFkZGluZ1xyXG4gICAgICAgICAgbWF4Wm9vbTogMTUsIC8vIEFkanVzdCB0aGUgbWF4aW11bSB6b29tIGxldmVsIGlmIG5lZWRlZFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSwgW2Nvb3JkaW5hdGVzXSk7XHJcblxyXG4gIC8vIEZ1bmN0aW9uIHRvIGhhbmRsZSBtYXAgY2xpY2sgZXZlbnRzXHJcbiAgZnVuY3Rpb24gb25NYXBDbGljayhlOiBNYXBMYXllck1vdXNlRXZlbnQpIHtcclxuICAgIGNvbnNvbGUubG9nKGUpO1xyXG4gICAgY29uc29sZS5sb2coZS5sbmdMYXQubGF0KTtcclxuICAgIGNvbnNvbGUubG9nKGUubG5nTGF0LmxuZyk7XHJcbiAgfVxyXG5cclxuICAvLyBGdW5jdGlvbiB0byBoYW5kbGUgZ2VvY29kaW5nIGJhc2VkIG9uIGlucHV0IGxhdGl0dWRlIGFuZCBsb25naXR1ZGVcclxuICBmdW5jdGlvbiBoYW5kbGVHZW9jb2RlKCkge1xyXG4gICAgLy8gUGFyc2UgbGF0aXR1ZGUgYW5kIGxvbmdpdHVkZSBpbnB1dCB2YWx1ZXMgYXMgbnVtYmVyc1xyXG4gICAgY29uc3QgbGF0ID0gcGFyc2VGbG9hdChpbnB1dExhdCk7XHJcbiAgICBjb25zdCBsbmcgPSBwYXJzZUZsb2F0KGlucHV0TG5nKTtcclxuXHJcbiAgICAvLyBDaGVjayBpZiB0aGUgdmFsdWVzIGFyZSB2YWxpZCBudW1iZXJzIHdpdGhpbiB0aGUgZXhwZWN0ZWQgcmFuZ2VcclxuICAgIGlmIChcclxuICAgICAgaXNOYU4obGF0KSB8fFxyXG4gICAgICBpc05hTihsbmcpIHx8XHJcbiAgICAgIGxhdCA8IC05MCB8fFxyXG4gICAgICBsYXQgPiA5MCB8fFxyXG4gICAgICBsbmcgPCAtMTgwIHx8XHJcbiAgICAgIGxuZyA+IDE4MFxyXG4gICAgKSB7XHJcbiAgICAgIGFsZXJ0KFxyXG4gICAgICAgIFwiSW52YWxpZCBsYXRpdHVkZSBvciBsb25naXR1ZGUgdmFsdWVzLiBQbGVhc2UgZW50ZXIgdmFsaWQgY29vcmRpbmF0ZXMuXCJcclxuICAgICAgKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFVzZSB0aGUgY29vcmRpbmF0ZXNHZW9jb2RlciBmdW5jdGlvbiB0byBjcmVhdGUgYSBHZW9KU09OIGZlYXR1cmVcclxuICAgIGNvbnN0IGdlb2NvZGVkRmVhdHVyZSA9IGNvb3JkaW5hdGVzR2VvY29kZXIoYCR7bG5nfSwgJHtsYXR9YCk7XHJcblxyXG4gICAgaWYgKGdlb2NvZGVkRmVhdHVyZSkge1xyXG4gICAgICAvLyBVcGRhdGUgdGhlIG1hcCB2aWV3IHN0YXRlIHdpdGggdGhlIGdlb2NvZGVkIGNvb3JkaW5hdGVzXHJcbiAgICAgIHNldFZpZXdTdGF0ZSh7XHJcbiAgICAgICAgbG9uZ2l0dWRlOiBsbmcsXHJcbiAgICAgICAgbGF0aXR1ZGU6IGxhdCxcclxuICAgICAgICB6b29tOiBpbml0aWFsWm9vbSxcclxuICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhbGVydChcIkdlb2NvZGluZyBmYWlsZWQuIFBsZWFzZSBjaGVjayB5b3VyIGlucHV0IHZhbHVlcy5cIik7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gIC8qKlxyXG4gICAqIEhhbmRsZXMga2V5Ym9hcmQgc2hvcnRjdXQgdG8gc3VibWl0IGJ5IHByZXNzaW5nIEVudGVyIGluIGxvbmcgb3IgbGF0IGJveFxyXG4gICAqIEBwYXJhbSBlIGtleWJvYXJkIGV2ZW50IG9mIHByZXNzaW5nIEVudGVyIGtleVxyXG4gICAqL1xyXG4gIGZ1bmN0aW9uIGhhbmRsZUVudGVyUHJlc3MoZTogUmVhY3QuS2V5Ym9hcmRFdmVudCkge1xyXG4gICAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIpIHtcclxuICAgICAgaGFuZGxlR2VvY29kZSgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogV2VicGFnZSBhbHdheXMgbGlzdGVucyBvdXQgZm9yIEN0cmwrcSB0byBuYXZpZ2F0ZSBjdXJzb3IgdG8gbG9uZ2l0dWRlIGlucHV0IGJveFxyXG4gICAqL1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBoYW5kbGVLZXlQcmVzcyA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XHJcbiAgICAgIGlmIChlLmtleSA9PT0gXCJxXCIgJiYgZS5jdHJsS2V5KSB7XHJcbiAgICAgICAgLy8gRm9jdXMgb24gdGhlIGxvbmdpdHVkZSBpbnB1dCB3aGVuIEN0cmwrcSBpcyBwcmVzc2VkXHJcbiAgICAgICAgaWYgKGxhdGl0dWRlSW5wdXRSZWYuY3VycmVudCkge1xyXG4gICAgICAgICAgbGF0aXR1ZGVJbnB1dFJlZi5jdXJyZW50LmZvY3VzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleVByZXNzKTtcclxuXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXlQcmVzcyk7XHJcbiAgICB9O1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIHsvKiBMYXRpdHVkZSBhbmQgTG9uZ2l0dWRlIElucHV0IFNlY3Rpb24gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2VvY29kZS1jb250YWluZXJcIj5cclxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5wdXQtbGFiZWxcIj5MYXRpdHVkZTo8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGRcIlxyXG4gICAgICAgICAgdmFsdWU9e2lucHV0TGF0fVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRJbnB1dExhdChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGxhdGl0dWRlXCJcclxuICAgICAgICAgIG9uS2V5RG93bj17aGFuZGxlRW50ZXJQcmVzc31cclxuICAgICAgICAgIHJlZj17bGF0aXR1ZGVJbnB1dFJlZn1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbnB1dC1sYWJlbFwiPiBMb25naXR1ZGU6PC9sYWJlbD5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkXCJcclxuICAgICAgICAgIHZhbHVlPXtpbnB1dExuZ31cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW5wdXRMbmcoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBsb25naXR1ZGVcIlxyXG4gICAgICAgICAgb25LZXlEb3duPXtoYW5kbGVFbnRlclByZXNzfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJnZW9jb2RlLWJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUdlb2NvZGV9PlxyXG4gICAgICAgICAgR2VvY29kZVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBNYXAgQ29udGFpbmVyICovfVxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPVwibWFwLWNvbnRhaW5lclwiXHJcbiAgICAgICAgZGF0YS1sYXQ9e3ZpZXdTdGF0ZS5sYXRpdHVkZX1cclxuICAgICAgICBkYXRhLWxvbmc9e3ZpZXdTdGF0ZS5sb25naXR1ZGV9XHJcbiAgICAgICAgZGF0YS16b29tPXt2aWV3U3RhdGUuem9vbX1cclxuICAgICAgPlxyXG4gICAgICAgIDxNYXBcclxuICAgICAgICAgIHJlZj17bWFwUmVmfVxyXG4gICAgICAgICAgbWFwYm94QWNjZXNzVG9rZW49e0FDQ0VTU19UT0tFTn1cclxuICAgICAgICAgIGxvbmdpdHVkZT17dmlld1N0YXRlLmxvbmdpdHVkZX1cclxuICAgICAgICAgIGxhdGl0dWRlPXt2aWV3U3RhdGUubGF0aXR1ZGV9XHJcbiAgICAgICAgICB6b29tPXt2aWV3U3RhdGUuem9vbX1cclxuICAgICAgICAgIG9uTW92ZT17KGV2OiBWaWV3U3RhdGVDaGFuZ2VFdmVudCkgPT4gc2V0Vmlld1N0YXRlKGV2LnZpZXdTdGF0ZSl9XHJcbiAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIGhlaWdodDogXCI5NnZoXCIgfX1cclxuICAgICAgICAgIG1hcFN0eWxlPXtcIm1hcGJveDovL3N0eWxlcy9tYXBib3gvb3V0ZG9vcnMtdjEyXCJ9XHJcbiAgICAgICAgICBvbkNsaWNrPXtvbk1hcENsaWNrfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxOYXZpZ2F0aW9uQ29udHJvbCBzaG93Wm9vbT17dHJ1ZX0gLz5cclxuXHJcbiAgICAgICAgICB7LyogT3ZlcmxheSBEYXRhICovfVxyXG4gICAgICAgICAgPFNvdXJjZSBpZD1cImdlb19kYXRhXCIgdHlwZT1cImdlb2pzb25cIiBkYXRhPXtvdmVybGF5fT5cclxuICAgICAgICAgICAgPExheWVyXHJcbiAgICAgICAgICAgICAgaWQ9e2dlb0xheWVyLmlkfVxyXG4gICAgICAgICAgICAgIHR5cGU9e2dlb0xheWVyLnR5cGV9XHJcbiAgICAgICAgICAgICAgcGFpbnQ9e2dlb0xheWVyLnBhaW50fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9Tb3VyY2U+XHJcblxyXG4gICAgICAgICAgey8qIFJlbmRlciBoaWdobGlnaHRlZCBjb29yZGluYXRlcyBhcyBjaXJjbGVzIG9uIHRoZSBtYXAgKi99XHJcbiAgICAgICAgICB7aGlnaGxpZ2h0ZWRDb29yZGluYXRlcyAmJiAoXHJcbiAgICAgICAgICAgIDxTb3VyY2VcclxuICAgICAgICAgICAgICBpZD1cImhpZ2hsaWdodGVkX2Nvb3JkaW5hdGVzXCJcclxuICAgICAgICAgICAgICB0eXBlPVwiZ2VvanNvblwiXHJcbiAgICAgICAgICAgICAgZGF0YT17aGlnaGxpZ2h0ZWRDb29yZGluYXRlc31cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxMYXllclxyXG4gICAgICAgICAgICAgICAgaWQ9XCJoaWdobGlnaHRlZF9jb29yZGluYXRlc19sYXllclwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgIHBhaW50PXt7XHJcbiAgICAgICAgICAgICAgICAgIFwiY2lyY2xlLXJhZGl1c1wiOiA4LFxyXG4gICAgICAgICAgICAgICAgICBcImNpcmNsZS1jb2xvclwiOiBcIiNGRjRFNDBcIiwgLy8gcmVkIGNvbG9yIGZvciBoaWdobGlnaHRzXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvU291cmNlPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L01hcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG4vLyBFeHBvcnQgdGhlIE1hcGJveCBjb21wb25lbnRcclxuZXhwb3J0IGRlZmF1bHQgTWFwYm94O1xyXG4iXX0=