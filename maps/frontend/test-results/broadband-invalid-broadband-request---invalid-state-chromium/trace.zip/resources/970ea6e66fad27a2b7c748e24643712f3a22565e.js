import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css?t=1699714527458";
export function REPLHistory(props) {
  const {
    commandHistory,
    mode,
    commandResultMap,
    ariaLabel
  } = props;
  const renderData = (data) => {
    if (data.length === 0) {
      return "No data to display";
    }
    if (Array.isArray(data) && Array.isArray(data[0])) {
      return /* @__PURE__ */ jsxDEV("table", { className: "center-table", children: /* @__PURE__ */ jsxDEV("tbody", { children: data.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
        lineNumber: 40,
        columnNumber: 63
      }, this)) }, rowIndex, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
        lineNumber: 39,
        columnNumber: 60
      }, this)) }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
        lineNumber: 38,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
        lineNumber: 37,
        columnNumber: 14
      }, this);
    } else if (typeof data === "string") {
      return data;
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", "aria-live": "polite", "aria-label": ariaLabel, children: [
    /* @__PURE__ */ jsxDEV("h2", { "aria-live": "polite", children: "Command History" }, void 0, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { children: commandHistory.map((command, index) => /* @__PURE__ */ jsxDEV("div", { className: "history-element", children: /* @__PURE__ */ jsxDEV("li", { children: mode === "brief" ? (
      // Display in brief mode with only the output
      /* @__PURE__ */ jsxDEV("div", { className: "text-box", "aria-live": "polite", children: /* @__PURE__ */ jsxDEV("p", { children: [
        "Output:",
        " ",
        renderData(commandResultMap.get(command) ?? "No data")
      ] }, void 0, true, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
        lineNumber: 60,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
        lineNumber: 59,
        columnNumber: 11
      }, this)
    ) : (
      // Display in verbose mode with both command and output
      /* @__PURE__ */ jsxDEV("div", { className: "text-box", "aria-live": "polite", children: [
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Command: ",
          command.command
        ] }, void 0, true, {
          fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
          lineNumber: 67,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Output:",
          " ",
          renderData(commandResultMap.get(command) ?? "No data")
        ] }, void 0, true, {
          fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
          lineNumber: 68,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
        lineNumber: 66,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
      lineNumber: 56,
      columnNumber: 13
    }, this) }, index, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
      lineNumber: 55,
      columnNumber: 49
    }, this)) }, void 0, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx",
    lineNumber: 52,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNrQjtBQXJDbEIsT0FBTyxvQkFBb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBaUJwQixnQkFBU0EsWUFBWUMsT0FBeUI7QUFDbkQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQWdCQztBQUFBQSxJQUFNQztBQUFBQSxJQUFrQkM7QUFBQUEsRUFBVSxJQUFJSjtBQU85RCxRQUFNSyxhQUFhQSxDQUFDQyxTQUF3QjtBQUMxQyxRQUFJQSxLQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJQyxNQUFNQyxRQUFRSCxJQUFJLEtBQUtFLE1BQU1DLFFBQVFILEtBQUssQ0FBQyxDQUFDLEdBQUc7QUFFakQsYUFDRSx1QkFBQyxXQUFNLFdBQVUsZ0JBQ2YsaUNBQUMsV0FDRUEsZUFBS0ksSUFBSSxDQUFDQyxLQUFlQyxhQUN4Qix1QkFBQyxRQUNFRCxjQUFJRCxJQUFJLENBQUNHLE1BQWNDLGNBQ3RCLHVCQUFDLFFBQW9CRCxrQkFBWkMsV0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCLENBQzNCLEtBSE1GLFVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLENBQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxJQUVKLFdBQVcsT0FBT04sU0FBUyxVQUFVO0FBQ25DLGFBQU9BO0FBQUFBLElBSVQ7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsYUFBVSxVQUFTLGNBQVlGLFdBQzNEO0FBQUEsMkJBQUMsUUFBRyxhQUFVLFVBQVMsK0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0M7QUFBQSxJQUN0Qyx1QkFBQyxRQUNFSCx5QkFBZVMsSUFBSSxDQUFDSyxTQUFTQyxVQUM1Qix1QkFBQyxTQUFnQixXQUFVLG1CQUN6QixpQ0FBQyxRQUNFZCxtQkFBUztBQUFBO0FBQUEsTUFFUix1QkFBQyxTQUFJLFdBQVUsWUFBVyxhQUFVLFVBQ2xDLGlDQUFDLE9BQUU7QUFBQTtBQUFBLFFBQ087QUFBQSxRQUNQRyxXQUFXRixpQkFBaUJjLElBQUlGLE9BQU8sS0FBSyxTQUFTO0FBQUEsV0FGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUE7QUFBQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLFlBQVcsYUFBVSxVQUNsQztBQUFBLCtCQUFDLE9BQUU7QUFBQTtBQUFBLFVBQVVBLFFBQVFBO0FBQUFBLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkI7QUFBQSxRQUM3Qix1QkFBQyxPQUFFO0FBQUE7QUFBQSxVQUNPO0FBQUEsVUFDUFYsV0FBV0YsaUJBQWlCYyxJQUFJRixPQUFPLEtBQUssU0FBUztBQUFBLGFBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQSxLQXBCUUMsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBLENBQ0QsS0F4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLE9BM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0QkE7QUFFSjtBQUFDRSxLQWxFZW5CO0FBQVc7QUFBQW9CIiwibmFtZXMiOlsiUkVQTEhpc3RvcnkiLCJwcm9wcyIsImNvbW1hbmRIaXN0b3J5IiwibW9kZSIsImNvbW1hbmRSZXN1bHRNYXAiLCJhcmlhTGFiZWwiLCJyZW5kZXJEYXRhIiwiZGF0YSIsImxlbmd0aCIsIkFycmF5IiwiaXNBcnJheSIsIm1hcCIsInJvdyIsInJvd0luZGV4IiwiY2VsbCIsImNlbGxJbmRleCIsImNvbW1hbmQiLCJpbmRleCIsImdldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTEhpc3RvcnkudHN4Il0sImZpbGUiOiJDOi9Vc2Vycy9wcmFuYS9Eb2N1bWVudHMvR2l0SHViL21hcHMtcHJsYWtzaG0tdGJvbmFzL21hcHMvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUkVQTEhpc3RvcnkudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XHJcbmltcG9ydCB7IEhpc3RvcnlJdGVtIH0gZnJvbSBcIi4uL3R5cGVzL0hpc3RvcnlJdGVtXCI7XHJcblxyXG4vKipcclxuICogUHJvcHMgZm9yIHRoZSBSRVBMSGlzdG9yeSBjb21wb25lbnQuXHJcbiAqL1xyXG5pbnRlcmZhY2UgUkVQTEhpc3RvcnlQcm9wcyB7XHJcbiAgY29tbWFuZEhpc3Rvcnk6IEhpc3RvcnlJdGVtW107IC8vIEFycmF5IG9mIGNvbW1hbmQgaGlzdG9yeSBpdGVtc1xyXG4gIG1vZGU6IHN0cmluZzsgLy8gRGlzcGxheSBtb2RlLCBlaXRoZXIgXCJicmllZlwiIG9yIFwidmVyYm9zZVwiXHJcbiAgY29tbWFuZFJlc3VsdE1hcDogTWFwPEhpc3RvcnlJdGVtLCBbW11dIHwgc3RyaW5nPjsgLy8gTWFwIG9mIGNvbW1hbmQgcmVzdWx0c1xyXG4gIGFyaWFMYWJlbDogc3RyaW5nOyAvLyBBUklBIGxhYmVsIGZvciBhY2Nlc3NpYmlsaXR5XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDb21wb25lbnQgcmVzcG9uc2libGUgZm9yIGRpc3BsYXlpbmcgdGhlIGNvbW1hbmQgaGlzdG9yeSBhbmQgY29ycmVzcG9uZGluZyByZXN1bHRzLlxyXG4gKiBAcGFyYW0ge1JFUExIaXN0b3J5UHJvcHN9IHByb3BzIC0gVGhlIHByb3BlcnRpZXMgcmVxdWlyZWQgZm9yIHJlbmRlcmluZyB0aGUgY29tcG9uZW50LlxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIFJFUExIaXN0b3J5KHByb3BzOiBSRVBMSGlzdG9yeVByb3BzKSB7XHJcbiAgY29uc3QgeyBjb21tYW5kSGlzdG9yeSwgbW9kZSwgY29tbWFuZFJlc3VsdE1hcCwgYXJpYUxhYmVsIH0gPSBwcm9wcztcclxuXHJcbiAgLyoqXHJcbiAgICogRnVuY3Rpb24gZm9yIHJlbmRlcmluZyBkaWZmZXJlbnQgdHlwZXMgb2YgZGF0YSBpbiB0aGUgY29tbWFuZCBoaXN0b3J5LlxyXG4gICAqIEBwYXJhbSB7W1tdXSB8IHN0cmluZ30gZGF0YSAtIFRoZSBkYXRhIHRvIGJlIHJlbmRlcmVkLlxyXG4gICAqIEByZXR1cm5zIHtKU1guRWxlbWVudH0gLSBUaGUgcmVuZGVyZWQgZGF0YSBhcyBKU1guXHJcbiAgICovXHJcbiAgY29uc3QgcmVuZGVyRGF0YSA9IChkYXRhOiBbW11dIHwgc3RyaW5nKSA9PiB7XHJcbiAgICBpZiAoZGF0YS5sZW5ndGggPT09IDApIHtcclxuICAgICAgcmV0dXJuIFwiTm8gZGF0YSB0byBkaXNwbGF5XCI7XHJcbiAgICB9XHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheShkYXRhKSAmJiBBcnJheS5pc0FycmF5KGRhdGFbMF0pKSB7XHJcbiAgICAgIC8vIFJlbmRlciBhIHRhYmxlIGlmIHRoZSBkYXRhIGlzIGEgMkQgYXJyYXlcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwiY2VudGVyLXRhYmxlXCI+XHJcbiAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgIHtkYXRhLm1hcCgocm93OiBzdHJpbmdbXSwgcm93SW5kZXg6IG51bWJlcikgPT4gKFxyXG4gICAgICAgICAgICAgIDx0ciBrZXk9e3Jvd0luZGV4fT5cclxuICAgICAgICAgICAgICAgIHtyb3cubWFwKChjZWxsOiBzdHJpbmcsIGNlbGxJbmRleDogbnVtYmVyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBrZXk9e2NlbGxJbmRleH0+e2NlbGx9PC90ZD5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICA8L3RhYmxlPlxyXG4gICAgICApO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZGF0YSA9PT0gXCJzdHJpbmdcIikge1xyXG4gICAgICByZXR1cm4gZGF0YTtcclxuICAgICAgLy8gVW5jb21tZW50IHRoZSBmb2xsb3dpbmcgbGluZXMgdG8gZGlzcGxheSBKU09OIGRhdGFcclxuICAgICAgLy8gfSBlbHNlIHtcclxuICAgICAgLy8gICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoZGF0YSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbC1oaXN0b3J5XCIgYXJpYS1saXZlPVwicG9saXRlXCIgYXJpYS1sYWJlbD17YXJpYUxhYmVsfT5cclxuICAgICAgPGgyIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPkNvbW1hbmQgSGlzdG9yeTwvaDI+XHJcbiAgICAgIDx1bD5cclxuICAgICAgICB7Y29tbWFuZEhpc3RvcnkubWFwKChjb21tYW5kLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgPGRpdiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJoaXN0b3J5LWVsZW1lbnRcIj5cclxuICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgIHttb2RlID09PSBcImJyaWVmXCIgPyAoXHJcbiAgICAgICAgICAgICAgICAvLyBEaXNwbGF5IGluIGJyaWVmIG1vZGUgd2l0aCBvbmx5IHRoZSBvdXRwdXRcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ib3hcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgT3V0cHV0OntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB7cmVuZGVyRGF0YShjb21tYW5kUmVzdWx0TWFwLmdldChjb21tYW5kKSA/PyBcIk5vIGRhdGFcIil9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAvLyBEaXNwbGF5IGluIHZlcmJvc2UgbW9kZSB3aXRoIGJvdGggY29tbWFuZCBhbmQgb3V0cHV0XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYm94XCIgYXJpYS1saXZlPVwicG9saXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwPkNvbW1hbmQ6IHtjb21tYW5kLmNvbW1hbmR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgICAgICBPdXRwdXQ6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHtyZW5kZXJEYXRhKGNvbW1hbmRSZXN1bHRNYXAuZ2V0KGNvbW1hbmQpID8/IFwiTm8gZGF0YVwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L3VsPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=