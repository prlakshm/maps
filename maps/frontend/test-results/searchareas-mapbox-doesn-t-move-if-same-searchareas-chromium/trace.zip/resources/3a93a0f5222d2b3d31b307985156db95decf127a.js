import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPL.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1e5b9a8a"; const useState = __vite__cjsImport3_react["useState"];
import "/src/styles/main.css?t=1699714527458";
import { REPLHistory } from "/src/components/REPLHistory.tsx?t=1699714527458";
import { REPLInput } from "/src/components/REPLInput.tsx?t=1699721661585";
export default function REPL({
  coordinates,
  setCoordinates
}) {
  _s();
  const [history, setHistory] = useState([]);
  const [mode, setMode] = useState("brief");
  const [commandResultMap, setCommandResultMap] = useState(/* @__PURE__ */ new Map());
  function updateCommandResult(command, result) {
    const historyItem = {
      command,
      timestamp: (/* @__PURE__ */ new Date()).getTime()
    };
    commandResultMap.set(historyItem, result);
    setHistory((prevHistory) => [...prevHistory, historyItem]);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { commandHistory: history, mode, commandResultMap, ariaLabel: "History Log Display to show past commands inputted" }, void 0, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPL.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPL.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPLInput, { history, setHistory, mode, setMode, commandResultMap, updateCommandResult, ariaLabel: "Input Command Component to take in and process command inputs", coordinates, setCoordinates }, void 0, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPL.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPL.tsx",
    lineNumber: 49,
    columnNumber: 10
  }, this);
}
_s(REPL, "MI9yKj6bEoyKNR+lE9l8G06o4bw=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0RNOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEROLFNBQW1DQSxnQkFBZ0I7QUFDbkQsT0FBTztBQUNQLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxpQkFBaUI7QUFhMUIsd0JBQXdCQyxLQUFLO0FBQUEsRUFBRUM7QUFBQUEsRUFBYUM7QUFBMEIsR0FBRztBQUFBQztBQUV2RSxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSVIsU0FBd0IsRUFBRTtBQUd4RCxRQUFNLENBQUNTLE1BQU1DLE9BQU8sSUFBSVYsU0FBaUIsT0FBTztBQUdoRCxRQUFNLENBQUNXLGtCQUFrQkMsbUJBQW1CLElBQUlaLFNBQVMsb0JBQUlhLElBQUcsQ0FBRTtBQU9sRSxXQUFTQyxvQkFBb0JDLFNBQWlCQyxRQUF1QjtBQUVuRSxVQUFNQyxjQUEyQjtBQUFBLE1BQy9CRjtBQUFBQSxNQUNBRyxZQUFXLG9CQUFJQyxLQUFJLEdBQUdDLFFBQU87QUFBQSxJQUMvQjtBQUdBVCxxQkFBaUJVLElBQUlKLGFBQWFELE1BQU07QUFHeENSLGVBQVljLGlCQUFnQixDQUFDLEdBQUdBLGFBQWFMLFdBQVcsQ0FBQztBQUFBLEVBQzNEO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFFYjtBQUFBLDJCQUFDLGVBQ0MsZ0JBQWdCVixTQUNoQixNQUNBLGtCQUNBLFdBQVUsd0RBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlnRTtBQUFBLElBRWhFLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFJO0FBQUEsSUFFSix1QkFBQyxhQUNDLFNBQ0EsWUFDQSxNQUNBLFNBQ0Esa0JBQ0EscUJBQ0EsV0FBVSxpRUFDVixhQUNBLGtCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTaUM7QUFBQSxPQW5CbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFCQTtBQUVKO0FBQUNELEdBckR1QkgsTUFBSTtBQUFBb0IsS0FBSnBCO0FBQUk7QUFBQXFCIiwibmFtZXMiOlsidXNlU3RhdGUiLCJSRVBMSGlzdG9yeSIsIlJFUExJbnB1dCIsIlJFUEwiLCJjb29yZGluYXRlcyIsInNldENvb3JkaW5hdGVzIiwiX3MiLCJoaXN0b3J5Iiwic2V0SGlzdG9yeSIsIm1vZGUiLCJzZXRNb2RlIiwiY29tbWFuZFJlc3VsdE1hcCIsInNldENvbW1hbmRSZXN1bHRNYXAiLCJNYXAiLCJ1cGRhdGVDb21tYW5kUmVzdWx0IiwiY29tbWFuZCIsInJlc3VsdCIsImhpc3RvcnlJdGVtIiwidGltZXN0YW1wIiwiRGF0ZSIsImdldFRpbWUiLCJzZXQiLCJwcmV2SGlzdG9yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTC50c3giXSwiZmlsZSI6IkM6L1VzZXJzL3ByYW5hL0RvY3VtZW50cy9HaXRIdWIvbWFwcy1wcmxha3NobS10Ym9uYXMvbWFwcy9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9SRVBMLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XHJcbmltcG9ydCB7IFJFUExIaXN0b3J5IH0gZnJvbSBcIi4vUkVQTEhpc3RvcnlcIjtcclxuaW1wb3J0IHsgUkVQTElucHV0IH0gZnJvbSBcIi4vUkVQTElucHV0XCI7XHJcbmltcG9ydCB7IEhpc3RvcnlJdGVtIH0gZnJvbSBcIi4uL3R5cGVzL0hpc3RvcnlJdGVtXCI7XHJcblxyXG5pbnRlcmZhY2UgUkVQTFByb3BzIHtcclxuICBjb29yZGluYXRlczogbnVtYmVyW11bXTtcclxuICBzZXRDb29yZGluYXRlczogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248bnVtYmVyW11bXT4+O1xyXG59XHJcbi8qKlxyXG4gKiBSZWFjdCBjb21wb25lbnQgYWxsb3dpbmcgdXNlcnMgdG8gaW5wdXQgY29tbWFuZHM7XHJcbiAqIERpc3BsYXlzIGNvcnJlc3BvbmRpbmcgY29tbWFuZCBoaXN0b3J5LCBhbmQgc2hvd3MgdGhlIHJlc3VsdHMgb2YgZWFjaCBjb21tYW5kLlxyXG4gKiBEZXBlbmRpbmcgb24gdGhlIG1vZGUgc2VsZWN0ZWQsIGNhbiBkaXNwbGF5IGVpdGhlciBqdXN0IHRoZSBvdXRwdXQsXHJcbiAqIG9yIGJvdGggdGhlIHVzZXIncyBjb21tYW5kIGFuZCB0aGUgb3V0cHV0LlxyXG4gKi9cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUkVQTCh7IGNvb3JkaW5hdGVzLCBzZXRDb29yZGluYXRlcyB9OiBSRVBMUHJvcHMpIHtcclxuICAvLyBTdGF0ZSB0byBtYW5hZ2UgdGhlIGNvbW1hbmQgaGlzdG9yeVxyXG4gIGNvbnN0IFtoaXN0b3J5LCBzZXRIaXN0b3J5XSA9IHVzZVN0YXRlPEhpc3RvcnlJdGVtW10+KFtdKTtcclxuXHJcbiAgLy8gU3RhdGUgdG8gbWFuYWdlIHRoZSBkaXNwbGF5IG1vZGUgKGJyaWVmIG9yIHZlcmJvc2UpXHJcbiAgY29uc3QgW21vZGUsIHNldE1vZGVdID0gdXNlU3RhdGU8c3RyaW5nPihcImJyaWVmXCIpO1xyXG5cclxuICAvLyBTdGF0ZSB0byBzdG9yZSBjb21tYW5kIHJlc3VsdHMgdXNpbmcgYSBNYXBcclxuICBjb25zdCBbY29tbWFuZFJlc3VsdE1hcCwgc2V0Q29tbWFuZFJlc3VsdE1hcF0gPSB1c2VTdGF0ZShuZXcgTWFwKCkpO1xyXG5cclxuICAvKipcclxuICAgKiBVcGRhdGUgdGhlIGNvbW1hbmQgcmVzdWx0IGFuZCBhZGQgaXQgdG8gdGhlIGNvbW1hbmQgaGlzdG9yeS5cclxuICAgKiBAcGFyYW0ge3N0cmluZ30gY29tbWFuZCAtIFRoZSB1c2VyJ3MgaW5wdXQgY29tbWFuZC5cclxuICAgKiBAcGFyYW0ge1tbXV0gfCBzdHJpbmcgfSByZXN1bHQgLSBUaGUgcmVzdWx0IG9mIHRoZSBjb21tYW5kIGV4ZWN1dGlvbi5cclxuICAgKi9cclxuICBmdW5jdGlvbiB1cGRhdGVDb21tYW5kUmVzdWx0KGNvbW1hbmQ6IHN0cmluZywgcmVzdWx0OiBbW11dIHwgc3RyaW5nKSB7XHJcbiAgICAvLyBDcmVhdGUgYSBoaXN0b3J5IGl0ZW0gd2l0aCB0aGUgdXNlcidzIGNvbW1hbmQgYW5kIHRpbWVzdGFtcFxyXG4gICAgY29uc3QgaGlzdG9yeUl0ZW06IEhpc3RvcnlJdGVtID0ge1xyXG4gICAgICBjb21tYW5kOiBjb21tYW5kLFxyXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkuZ2V0VGltZSgpLFxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBBZGQgdGhlIHJlc3VsdCB0byB0aGUgY29tbWFuZFJlc3VsdE1hcCB1c2luZyB0aGUgaGlzdG9yeSBpdGVtIGFzIHRoZSBrZXlcclxuICAgIGNvbW1hbmRSZXN1bHRNYXAuc2V0KGhpc3RvcnlJdGVtLCByZXN1bHQpO1xyXG5cclxuICAgIC8vIFVwZGF0ZSB0aGUgY29tbWFuZCBoaXN0b3J5IHdpdGggdGhlIG5ldyBoaXN0b3J5IGl0ZW1cclxuICAgIHNldEhpc3RvcnkoKHByZXZIaXN0b3J5KSA9PiBbLi4ucHJldkhpc3RvcnksIGhpc3RvcnlJdGVtXSk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsXCI+XHJcbiAgICAgIHsvKiBEaXNwbGF5IHRoZSBjb21tYW5kIGhpc3RvcnkgY29tcG9uZW50ICovfVxyXG4gICAgICA8UkVQTEhpc3RvcnlcclxuICAgICAgICBjb21tYW5kSGlzdG9yeT17aGlzdG9yeX1cclxuICAgICAgICBtb2RlPXttb2RlfVxyXG4gICAgICAgIGNvbW1hbmRSZXN1bHRNYXA9e2NvbW1hbmRSZXN1bHRNYXB9XHJcbiAgICAgICAgYXJpYUxhYmVsPVwiSGlzdG9yeSBMb2cgRGlzcGxheSB0byBzaG93IHBhc3QgY29tbWFuZHMgaW5wdXR0ZWRcIlxyXG4gICAgICAvPlxyXG4gICAgICA8aHI+PC9ocj5cclxuICAgICAgey8qIERpc3BsYXkgdGhlIGlucHV0IGNvbXBvbmVudCBmb3IgdXNlciBjb21tYW5kcyAqL31cclxuICAgICAgPFJFUExJbnB1dFxyXG4gICAgICAgIGhpc3Rvcnk9e2hpc3Rvcnl9XHJcbiAgICAgICAgc2V0SGlzdG9yeT17c2V0SGlzdG9yeX1cclxuICAgICAgICBtb2RlPXttb2RlfVxyXG4gICAgICAgIHNldE1vZGU9e3NldE1vZGV9XHJcbiAgICAgICAgY29tbWFuZFJlc3VsdE1hcD17Y29tbWFuZFJlc3VsdE1hcH1cclxuICAgICAgICB1cGRhdGVDb21tYW5kUmVzdWx0PXt1cGRhdGVDb21tYW5kUmVzdWx0fVxyXG4gICAgICAgIGFyaWFMYWJlbD1cIklucHV0IENvbW1hbmQgQ29tcG9uZW50IHRvIHRha2UgaW4gYW5kIHByb2Nlc3MgY29tbWFuZCBpbnB1dHNcIlxyXG4gICAgICAgIGNvb3JkaW5hdGVzPXtjb29yZGluYXRlc31cclxuICAgICAgICBzZXRDb29yZGluYXRlcz17c2V0Q29vcmRpbmF0ZXN9XHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==