import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZOIWZPCO.js?v=1e5b9a8a";
import "/node_modules/.vite/deps/chunk-DFKQJ226.js?v=1e5b9a8a";
export default require_react();
//# sourceMappingURL=react.js.map
