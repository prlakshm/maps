import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=1e5b9a8a"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=1e5b9a8a"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import App from "/src/components/App.tsx?t=1699721661585";
import "/src/styles/index.css";
ReactDOM.createRoot(document.getElementById("root")).render(
  // Wrap your App component with React.StrictMode for development-related checks.
  /* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/main.tsx",
    lineNumber: 11,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/main.tsx",
    lineNumber: 10,
    columnNumber: 1
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7QUFUSixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsU0FBUztBQUNoQixPQUFPO0FBR1BELFNBQVNFLFdBQVdDLFNBQVNDLGVBQWUsTUFBTSxDQUFnQixFQUFFQztBQUFBQTtBQUFBQSxFQUVsRSx1QkFBQyxNQUFNLFlBQU4sRUFDQyxpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUFtQiIsIm5hbWVzIjpbIlJlYWN0IiwiUmVhY3RET00iLCJBcHAiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sImZpbGUiOiJDOi9Vc2Vycy9wcmFuYS9Eb2N1bWVudHMvR2l0SHViL21hcHMtcHJsYWtzaG0tdGJvbmFzL21hcHMvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvbWFpbi50c3giLCJzb3VyY2VzQ29udGVudCI6WyIvLyBJbXBvcnQgUmVhY3QsIFJlYWN0RE9NLCB5b3VyIG1haW4gQXBwIGNvbXBvbmVudCwgYW5kIHN0eWxlcy5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgUmVhY3RET00gZnJvbSBcInJlYWN0LWRvbS9jbGllbnRcIjtcclxuaW1wb3J0IEFwcCBmcm9tIFwiLi9BcHBcIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL2luZGV4LmNzc1wiO1xyXG5cclxuLy8gVXNlIFJlYWN0RE9NLmNyZWF0ZVJvb3QgdG8gcmVuZGVyIHlvdXIgYXBwIGludG8gdGhlIHJvb3QgZWxlbWVudCBpbiBcImluZGV4Lmh0bWxcIi5cclxuUmVhY3RET00uY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIikgYXMgSFRNTEVsZW1lbnQpLnJlbmRlcihcclxuICAvLyBXcmFwIHlvdXIgQXBwIGNvbXBvbmVudCB3aXRoIFJlYWN0LlN0cmljdE1vZGUgZm9yIGRldmVsb3BtZW50LXJlbGF0ZWQgY2hlY2tzLlxyXG4gIDxSZWFjdC5TdHJpY3RNb2RlPlxyXG4gICAgPEFwcCAvPlxyXG4gIDwvUmVhY3QuU3RyaWN0TW9kZT5cclxuKTtcclxuIl19