import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1e5b9a8a"; const useState = __vite__cjsImport3_react["useState"];
import "/src/styles/App.css";
import Mapbox from "/src/components/Mapbox.tsx";
import REPL from "/src/components/REPL.tsx?t=1699721661585";
function App() {
  _s();
  const [coordinates, setCoordinates] = useState([]);
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "App-header", children: "Maps" }, void 0, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/App.tsx",
      lineNumber: 12,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "app-style", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "leftColumnStyle", children: /* @__PURE__ */ jsxDEV(Mapbox, { coordinates, setCoordinates }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/App.tsx",
        lineNumber: 15,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/App.tsx",
        lineNumber: 14,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rightColumnStyle", children: /* @__PURE__ */ jsxDEV(REPL, { coordinates, setCoordinates }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/App.tsx",
        lineNumber: 18,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/App.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/App.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/App.tsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
}
_s(App, "tEVF8+bDlMrQ6mrJOrcZsN2wGrE=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFaTixTQUEyQkEsZ0JBQWdCO0FBQzNDLE9BQU87QUFDUCxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLFVBQVU7QUFJakIsU0FBU0MsTUFBTTtBQUFBQztBQUNiLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJTixTQUFxQixFQUFFO0FBRTdELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwyQkFBQyxZQUFPLFdBQVUsY0FBYSxvQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQztBQUFBLElBQ25DLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1CQUNiLGlDQUFDLFVBQ0MsYUFDQSxrQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0MsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxRQUFLLGFBQTBCLGtCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStELEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsT0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYUE7QUFFSjtBQUVBSSxHQXJCU0QsS0FBRztBQUFBSSxLQUFISjtBQXNCVCxlQUFlQTtBQUFJO0FBQUFLIiwibmFtZXMiOlsidXNlU3RhdGUiLCJNYXBib3giLCJSRVBMIiwiQXBwIiwiX3MiLCJjb29yZGluYXRlcyIsInNldENvb3JkaW5hdGVzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sImZpbGUiOiJDOi9Vc2Vycy9wcmFuYS9Eb2N1bWVudHMvR2l0SHViL21hcHMtcHJsYWtzaG0tdGJvbmFzL21hcHMvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQXBwLnRzeCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9BcHAuY3NzXCI7XHJcbmltcG9ydCBNYXBib3ggZnJvbSBcIi4vTWFwYm94XCI7XHJcbmltcG9ydCBSRVBMIGZyb20gXCIuL1JFUExcIjtcclxuXHJcblxyXG4vLyBUaGlzIGlzIHRoZSBtYWluIGZ1bmN0aW9uYWwgY29tcG9uZW50IG5hbWVkIFwiQXBwXCIgdGhhdCByZXByZXNlbnRzIHRoZSByb290IG9mIHRoZSBhcHBsaWNhdGlvbi5cclxuZnVuY3Rpb24gQXBwKCkge1xyXG4gIGNvbnN0IFtjb29yZGluYXRlcywgc2V0Q29vcmRpbmF0ZXNdID0gdXNlU3RhdGU8bnVtYmVyW11bXT4oW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJBcHBcIj5cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJBcHAtaGVhZGVyXCI+TWFwczwvaGVhZGVyPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcC1zdHlsZVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVmdENvbHVtblN0eWxlXCI+XHJcbiAgICAgICAgICA8TWFwYm94XHJcbiAgICAgICAgICAgIGNvb3JkaW5hdGVzPXtjb29yZGluYXRlc31cclxuICAgICAgICAgICAgc2V0Q29vcmRpbmF0ZXM9e3NldENvb3JkaW5hdGVzfVxyXG4gICAgICAgICAgPjwvTWFwYm94PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlnaHRDb2x1bW5TdHlsZVwiPlxyXG4gICAgICAgICAgPFJFUEwgY29vcmRpbmF0ZXM9e2Nvb3JkaW5hdGVzfSBzZXRDb29yZGluYXRlcz17c2V0Q29vcmRpbmF0ZXN9IC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuLy8gRXhwb3J0IHRoZSBcIkFwcFwiIGNvbXBvbmVudCBzbyBpdCBjYW4gYmUgdXNlZCBpbiBvdGhlciBwYXJ0cyBvZiB0aGUgYXBwbGljYXRpb24uXHJcbmV4cG9ydCBkZWZhdWx0IEFwcDtcclxuIl19