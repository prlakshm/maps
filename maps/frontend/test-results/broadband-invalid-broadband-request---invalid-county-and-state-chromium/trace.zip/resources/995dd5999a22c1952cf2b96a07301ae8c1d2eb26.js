import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css?t=1699714527458";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=1e5b9a8a"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx?t=1699714527458";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=1e5b9a8a"; const useEffect = __vite__cjsImport6_react["useEffect"];
const commandRegistry = /* @__PURE__ */ new Map();
function registerCommand(command, func) {
  commandRegistry.set(command, func);
}
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const {
    mode,
    setMode,
    history,
    setHistory,
    commandResultMap,
    updateCommandResult,
    ariaLabel,
    coordinates,
    setCoordinates
  } = props;
  const handleRegister = async (args) => {
    if (args.length !== 2) {
      return "Invalid usage of 'register' command. Usage: register <commandName> <functionToExecute>";
    }
    const commandName = args[0];
    const toExecute = args[1];
    if (commandRegistry.has(commandName)) {
      return "Command: " + commandName + " is already registered";
    } else {
      registerCommand(commandName, eval(toExecute));
      return "Command registered: " + commandName;
    }
  };
  const handleMode = async (args2) => {
    const validModes = ["brief", "verbose"];
    if (args2.length !== 1) {
      return "Invalid usage of 'mode' command. Usage: mode <newMode>";
    }
    if (validModes.includes(args2[0])) {
      setMode(args2[0]);
      return "Mode changed to " + args2[0];
    } else {
      return "Invalid mode: " + args2[0] + ". Use brief or verbose";
    }
  };
  const handleLoad = async (args2) => {
    if (args2.length !== 1) {
      return "Invalid usage of 'load' command. Usage: load <URL>";
    }
    const filepath = args2[0].trim();
    try {
      const response = await fetch(`http://localhost:4000/loadcsv?filepath=${filepath}`);
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? "File " + filepath + " loaded successfully" : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error ocurred while loading the file: " + error;
    }
  };
  const handleView = async (args2) => {
    if (args2.length !== 0) {
      return "Invalid usage of 'view' command. Usage: view";
    }
    try {
      const response = await fetch("http://localhost:4000/viewcsv");
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? data.data : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error occurred while viewing the file: " + error;
    }
  };
  const handleSearch = async (args2) => {
    if (args2.length !== 3) {
      return "Invalid search command. Usage: search <hasHeaders> <value> <columnId>";
    }
    const hasHeaders = args2[0];
    const value = args2[1].includes("%") ? args2[1].replace("%", "%25").replace(/_/g, " ") : args2[1].replace(/_/g, " ");
    const columnId = args2[2].replace(/_/g, " ");
    try {
      const response = await fetch(`http://localhost:4000/searchcsv?headers=${hasHeaders}&value=${value}&colid=${columnId}`);
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? data.data : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error occurred while searching through the file: " + error;
    }
  };
  const handleBroadband = async (args2) => {
    if (args2.length !== 2) {
      return "Invalid broadband retrieval command. Usage: broadband <state> <county>";
    }
    const state = args2[0].replace(/_/g, " ");
    const county = args2[1].replace(/_/g, " ");
    try {
      const response = await fetch(`http://localhost:4000/broadband?state=${state}&county=${county}`);
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? `time of retrieval: ${data.date_time} broadband access percent: ${data.broadband_access_percent}` : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error occurred while fetching broadband data: " + error;
    }
  };
  const handleAreas = async (args2) => {
    if (args2.length !== 1) {
      return "Invalid usage of 'searchareas' command. Usage: searchareas <keyword>";
    }
    const keyword = args2[0].trim();
    try {
      const response = await fetch(`http://localhost:4000/searchareas?keyword=${keyword}`);
      if (response.ok) {
        const data = await response.json();
        setCoordinates(data.coordinatesList);
        const resultMessage = data.result === "success" ? "Areas descriptions with " + keyword + " highlighted successfully" : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch areas from the backend";
    } catch (error) {
      return "An error ocurred while searching for areas: " + error;
    }
  };
  useEffect(() => {
    registerCommand("register", handleRegister);
    registerCommand("mode", handleMode);
    registerCommand("load", handleLoad);
    registerCommand("view", handleView);
    registerCommand("search", handleSearch);
    registerCommand("broadband", handleBroadband);
    registerCommand("searchareas", handleAreas);
  }, []);
  async function executeCommand(commandName2, args2) {
    const func = commandRegistry.get(commandName2);
    if (func) {
      try {
        const result = await func(args2);
        return result;
      } catch (error) {
        return `Error executing command. ${error}`;
      }
    } else {
      return `Command not found: ${commandName2}. Input "register <commandName> <function>" to register new command`;
    }
  }
  function handleSubmit(commandString2) {
    const trimmedCommand = commandString2.trim();
    if (trimmedCommand === "") {
      alert("Command cannot be empty");
      return;
    }
    const args2 = trimmedCommand.split(/\s+/);
    executeCommand(args2[0], args2.slice(1)).then((result) => {
      updateCommandResult(commandString2, result);
      setCount(count + 1);
    });
    setCommandString("");
  }
  function handleEnterPress(e) {
    if (e.key === "Enter") {
      handleSubmit(commandString);
    }
  }
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === "b" && e.ctrlKey) {
        const inputElement = document.querySelector(".repl-command-box");
        if (inputElement && inputElement instanceof HTMLInputElement)
          inputElement.focus();
      }
    };
    document.addEventListener("keydown", handleKeyPress);
    return () => {
      document.removeEventListener("keydown", handleKeyPress);
    };
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", "aria-live": "polite", "aria-label": ariaLabel, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLInput.tsx",
        lineNumber: 290,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command Input Box to type in commands", onKeyDown: handleEnterPress }, void 0, false, {
        fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLInput.tsx",
        lineNumber: 291,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLInput.tsx",
      lineNumber: 289,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { "aria-label": "repl-input-submit-button", onClick: () => handleSubmit(commandString), children: "Submit" }, void 0, false, {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLInput.tsx",
      lineNumber: 293,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLInput.tsx",
    lineNumber: 288,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "ENpYGy7RzhD7Zwuou93UyOmtyqg=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc1VROzs7Ozs7Ozs7Ozs7Ozs7O0FBdFVSLE9BQU87QUFDUCxTQUFtQ0EsZ0JBQWdCO0FBQ25ELFNBQVNDLHVCQUF1QjtBQUdoQyxTQUFTQyxpQkFBaUI7QUFJMUIsTUFBTUMsa0JBQWtCLG9CQUFJQyxJQUF5QjtBQU9yRCxTQUFTQyxnQkFBZ0JDLFNBQWlCQyxNQUFvQjtBQUM1REosa0JBQWdCSyxJQUFJRixTQUFTQyxJQUFJO0FBQ25DO0FBcUJPLGdCQUFTRSxVQUFVQyxPQUF1QjtBQUFBQztBQUMvQyxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJYixTQUFpQixFQUFFO0FBQzdELFFBQU0sQ0FBQ2MsT0FBT0MsUUFBUSxJQUFJZixTQUFpQixDQUFDO0FBQzVDLFFBQU07QUFBQSxJQUNKZ0I7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJZDtBQU1KLFFBQU1lLGlCQUErQixPQUNuQ0MsU0FDb0I7QUFDcEIsUUFBSUEsS0FBS0MsV0FBVyxHQUFHO0FBQ3JCLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTUMsY0FBY0YsS0FBSyxDQUFDO0FBQzFCLFVBQU1HLFlBQVlILEtBQUssQ0FBQztBQUN4QixRQUFJdkIsZ0JBQWdCMkIsSUFBSUYsV0FBVyxHQUFHO0FBQ3BDLGFBQU8sY0FBY0EsY0FBYztBQUFBLElBQ3JDLE9BQU87QUFDTHZCLHNCQUFnQnVCLGFBQWFHLEtBQUtGLFNBQVMsQ0FBQztBQUM1QyxhQUFPLHlCQUF5QkQ7QUFBQUEsSUFDbEM7QUFBQSxFQUNGO0FBT0EsUUFBTUksYUFBMkIsT0FBT04sVUFBb0M7QUFDMUUsVUFBTU8sYUFBYSxDQUFDLFNBQVMsU0FBUztBQUN0QyxRQUFJUCxNQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJTSxXQUFXQyxTQUFTUixNQUFLLENBQUMsQ0FBQyxHQUFHO0FBQ2hDVCxjQUFRUyxNQUFLLENBQUMsQ0FBQztBQUNmLGFBQU8scUJBQXFCQSxNQUFLLENBQUM7QUFBQSxJQUNwQyxPQUFPO0FBQ0wsYUFBTyxtQkFBbUJBLE1BQUssQ0FBQyxJQUFJO0FBQUEsSUFDdEM7QUFBQSxFQUNGO0FBTUEsUUFBTVMsYUFBMkIsT0FBT1QsVUFBb0M7QUFDMUUsUUFBSUEsTUFBS0MsV0FBVyxHQUFHO0FBQ3JCLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTVMsV0FBV1YsTUFBSyxDQUFDLEVBQUVXLEtBQUk7QUFDN0IsUUFBSTtBQUNGLFlBQU1DLFdBQVcsTUFBTUMsTUFDcEIsMENBQXlDSCxVQUFVO0FBRXRELFVBQUlFLFNBQVNFLElBQUk7QUFDZixjQUFNQyxPQUFPLE1BQU1ILFNBQVNJLEtBQUk7QUFDaEMsY0FBTUMsZ0JBQ0pGLEtBQUtHLFdBQVcsWUFDWixVQUFVUixXQUFXLHlCQUNyQkssS0FBS0k7QUFDWCxlQUFPRjtBQUFBQSxNQUNUO0FBQU8sZUFBTztBQUFBLElBQ2hCLFNBQVNHLE9BQVA7QUFHQSxhQUFPLDhDQUE4Q0E7QUFBQUEsSUFDdkQ7QUFBQSxFQUNGO0FBTUEsUUFBTUMsYUFBMkIsT0FBT3JCLFVBQW9DO0FBQzFFLFFBQUlBLE1BQUtDLFdBQVcsR0FBRztBQUNyQixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUk7QUFDRixZQUFNVyxXQUFXLE1BQU1DLE1BQU0sK0JBQStCO0FBQzVELFVBQUlELFNBQVNFLElBQUk7QUFDZixjQUFNQyxPQUFPLE1BQU1ILFNBQVNJLEtBQUk7QUFDaEMsY0FBTUMsZ0JBQ0pGLEtBQUtHLFdBQVcsWUFBWUgsS0FBS0EsT0FBT0EsS0FBS0k7QUFDL0MsZUFBT0Y7QUFBQUEsTUFDVDtBQUFPLGVBQU87QUFBQSxJQUNoQixTQUFTRyxPQUFQO0FBQ0EsYUFBTywrQ0FBK0NBO0FBQUFBLElBQ3hEO0FBQUEsRUFDRjtBQU1BLFFBQU1FLGVBQTZCLE9BQ2pDdEIsVUFDb0I7QUFDcEIsUUFBSUEsTUFBS0MsV0FBVyxHQUFHO0FBQ3JCLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTXNCLGFBQWF2QixNQUFLLENBQUM7QUFDekIsVUFBTXdCLFFBQVF4QixNQUFLLENBQUMsRUFBRVEsU0FBUyxHQUFHLElBQzlCUixNQUFLLENBQUMsRUFBRXlCLFFBQVEsS0FBSyxLQUFLLEVBQUVBLFFBQVEsTUFBTSxHQUFHLElBQzdDekIsTUFBSyxDQUFDLEVBQUV5QixRQUFRLE1BQU0sR0FBRztBQUM3QixVQUFNQyxXQUFXMUIsTUFBSyxDQUFDLEVBQUV5QixRQUFRLE1BQU0sR0FBRztBQUUxQyxRQUFJO0FBQ0YsWUFBTWIsV0FBVyxNQUFNQyxNQUNwQiwyQ0FBMENVLG9CQUFvQkMsZUFBZUUsVUFBVTtBQUUxRixVQUFJZCxTQUFTRSxJQUFJO0FBQ2YsY0FBTUMsT0FBTyxNQUFNSCxTQUFTSSxLQUFJO0FBQ2hDLGNBQU1DLGdCQUNKRixLQUFLRyxXQUFXLFlBQVlILEtBQUtBLE9BQU9BLEtBQUtJO0FBQy9DLGVBQU9GO0FBQUFBLE1BQ1Q7QUFBTyxlQUFPO0FBQUEsSUFDaEIsU0FBU0csT0FBUDtBQUNBLGFBQU8seURBQXlEQTtBQUFBQSxJQUNsRTtBQUFBLEVBQ0Y7QUFNQSxRQUFNTyxrQkFBZ0MsT0FDcEMzQixVQUNvQjtBQUNwQixRQUFJQSxNQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNMkIsUUFBUTVCLE1BQUssQ0FBQyxFQUFFeUIsUUFBUSxNQUFNLEdBQUc7QUFDdkMsVUFBTUksU0FBUzdCLE1BQUssQ0FBQyxFQUFFeUIsUUFBUSxNQUFNLEdBQUc7QUFFeEMsUUFBSTtBQUNGLFlBQU1iLFdBQVcsTUFBTUMsTUFDcEIseUNBQXdDZSxnQkFBZ0JDLFFBQVE7QUFFbkUsVUFBSWpCLFNBQVNFLElBQUk7QUFDZixjQUFNQyxPQUFPLE1BQU1ILFNBQVNJLEtBQUk7QUFDaEMsY0FBTUMsZ0JBQ0pGLEtBQUtHLFdBQVcsWUFDWCxzQkFBcUJILEtBQUtlLHVDQUF1Q2YsS0FBS2dCLDZCQUN2RWhCLEtBQUtJO0FBQ1gsZUFBT0Y7QUFBQUEsTUFDVDtBQUFPLGVBQU87QUFBQSxJQUNoQixTQUFTRyxPQUFQO0FBQ0EsYUFBTyxzREFBc0RBO0FBQUFBLElBQy9EO0FBQUEsRUFDRjtBQU1BLFFBQU1ZLGNBQTRCLE9BQU9oQyxVQUFvQztBQUMzRSxRQUFJQSxNQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNZ0MsVUFBVWpDLE1BQUssQ0FBQyxFQUFFVyxLQUFJO0FBQzVCLFFBQUk7QUFDRixZQUFNQyxXQUFXLE1BQU1DLE1BQ3BCLDZDQUE0Q29CLFNBQVM7QUFFeEQsVUFBSXJCLFNBQVNFLElBQUk7QUFDZixjQUFNQyxPQUFPLE1BQU1ILFNBQVNJLEtBQUk7QUFDaENsQix1QkFBZWlCLEtBQUttQixlQUFlO0FBRW5DLGNBQU1qQixnQkFDSkYsS0FBS0csV0FBVyxZQUNaLDZCQUE2QmUsVUFBVSw4QkFDdkNsQixLQUFLSTtBQUNYLGVBQU9GO0FBQUFBLE1BQ1Q7QUFBTyxlQUFPO0FBQUEsSUFDaEIsU0FBU0csT0FBUDtBQUVBLGFBQU8saURBQWlEQTtBQUFBQSxJQUMxRDtBQUFBLEVBQ0Y7QUFLQTVDLFlBQVUsTUFBTTtBQUNkRyxvQkFBZ0IsWUFBWW9CLGNBQWM7QUFDMUNwQixvQkFBZ0IsUUFBUTJCLFVBQVU7QUFDbEMzQixvQkFBZ0IsUUFBUThCLFVBQVU7QUFDbEM5QixvQkFBZ0IsUUFBUTBDLFVBQVU7QUFDbEMxQyxvQkFBZ0IsVUFBVTJDLFlBQVk7QUFDdEMzQyxvQkFBZ0IsYUFBYWdELGVBQWU7QUFDNUNoRCxvQkFBZ0IsZUFBZXFELFdBQVc7QUFBQSxFQUM1QyxHQUFHLEVBQUU7QUFPTCxpQkFBZUcsZUFDYmpDLGNBQ0FGLE9BQ2lCO0FBQ2pCLFVBQU1uQixPQUFPSixnQkFBZ0IyRCxJQUFJbEMsWUFBVztBQUU1QyxRQUFJckIsTUFBTTtBQUNSLFVBQUk7QUFFRixjQUFNcUMsU0FBUyxNQUFNckMsS0FBS21CLEtBQUk7QUFDOUIsZUFBT2tCO0FBQUFBLE1BQ1QsU0FBU0UsT0FBUDtBQUNBLGVBQVEsNEJBQTJCQTtBQUFBQSxNQUNyQztBQUFBLElBQ0YsT0FBTztBQUNMLGFBQVEsc0JBQXFCbEI7QUFBQUEsSUFDL0I7QUFBQSxFQUNGO0FBTUEsV0FBU21DLGFBQWFuRCxnQkFBdUI7QUFDM0MsVUFBTW9ELGlCQUFpQnBELGVBQWN5QixLQUFJO0FBQ3pDLFFBQUkyQixtQkFBbUIsSUFBSTtBQUN6QkMsWUFBTSx5QkFBeUI7QUFDL0I7QUFBQSxJQUNGO0FBR0EsVUFBTXZDLFFBQU9zQyxlQUFlRSxNQUFNLEtBQUs7QUFFdkNMLG1CQUFlbkMsTUFBSyxDQUFDLEdBQUdBLE1BQUt5QyxNQUFNLENBQUMsQ0FBQyxFQUFFQyxLQUFNeEIsWUFBVztBQUN0RHZCLDBCQUFvQlQsZ0JBQWVnQyxNQUFNO0FBQ3pDN0IsZUFBU0QsUUFBUSxDQUFDO0FBQUEsSUFDcEIsQ0FBQztBQUVERCxxQkFBaUIsRUFBRTtBQUFBLEVBQ3JCO0FBUUEsV0FBU3dELGlCQUFpQkMsR0FBd0I7QUFDaEQsUUFBSUEsRUFBRUMsUUFBUSxTQUFTO0FBQ3JCUixtQkFBYW5ELGFBQWE7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFLQVYsWUFBVSxNQUFNO0FBQ2QsVUFBTXNFLGlCQUFpQkEsQ0FBQ0YsTUFBcUI7QUFDM0MsVUFBSUEsRUFBRUMsUUFBUSxPQUFPRCxFQUFFRyxTQUFTO0FBQzlCLGNBQU1DLGVBQWVDLFNBQVNDLGNBQWMsbUJBQW1CO0FBQy9ELFlBQUlGLGdCQUFnQkEsd0JBQXdCRztBQUMxQ0gsdUJBQWFJLE1BQUs7QUFBQSxNQUN0QjtBQUFBLElBQ0Y7QUFFQUgsYUFBU0ksaUJBQWlCLFdBQVdQLGNBQWM7QUFFbkQsV0FBTyxNQUFNO0FBQ1hHLGVBQVNLLG9CQUFvQixXQUFXUixjQUFjO0FBQUEsSUFDeEQ7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUlMLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQWEsYUFBVSxVQUFTLGNBQVlsRCxXQUN6RDtBQUFBLDJCQUFDLGNBQ0M7QUFBQSw2QkFBQyxZQUFPLGdDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxtQkFDQyxPQUFPVixlQUNQLFVBQVVDLGtCQUNWLFdBQVcseUNBQ1gsV0FBV3dELG9CQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJOEI7QUFBQSxTQU5oQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFlBQ0MsY0FBVyw0QkFDWCxTQUFTLE1BQU1OLGFBQWFuRCxhQUFhLEdBQzFDLHNCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBQUNELEdBL1NlRixXQUFTO0FBQUF3RSxLQUFUeEU7QUFBUztBQUFBeUUiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsInVzZUVmZmVjdCIsImNvbW1hbmRSZWdpc3RyeSIsIk1hcCIsInJlZ2lzdGVyQ29tbWFuZCIsImNvbW1hbmQiLCJmdW5jIiwic2V0IiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsIm1vZGUiLCJzZXRNb2RlIiwiaGlzdG9yeSIsInNldEhpc3RvcnkiLCJjb21tYW5kUmVzdWx0TWFwIiwidXBkYXRlQ29tbWFuZFJlc3VsdCIsImFyaWFMYWJlbCIsImNvb3JkaW5hdGVzIiwic2V0Q29vcmRpbmF0ZXMiLCJoYW5kbGVSZWdpc3RlciIsImFyZ3MiLCJsZW5ndGgiLCJjb21tYW5kTmFtZSIsInRvRXhlY3V0ZSIsImhhcyIsImV2YWwiLCJoYW5kbGVNb2RlIiwidmFsaWRNb2RlcyIsImluY2x1ZGVzIiwiaGFuZGxlTG9hZCIsImZpbGVwYXRoIiwidHJpbSIsInJlc3BvbnNlIiwiZmV0Y2giLCJvayIsImRhdGEiLCJqc29uIiwicmVzdWx0TWVzc2FnZSIsInJlc3VsdCIsImVycm9yX21lc3NhZ2UiLCJlcnJvciIsImhhbmRsZVZpZXciLCJoYW5kbGVTZWFyY2giLCJoYXNIZWFkZXJzIiwidmFsdWUiLCJyZXBsYWNlIiwiY29sdW1uSWQiLCJoYW5kbGVCcm9hZGJhbmQiLCJzdGF0ZSIsImNvdW50eSIsImRhdGVfdGltZSIsImJyb2FkYmFuZF9hY2Nlc3NfcGVyY2VudCIsImhhbmRsZUFyZWFzIiwia2V5d29yZCIsImNvb3JkaW5hdGVzTGlzdCIsImV4ZWN1dGVDb21tYW5kIiwiZ2V0IiwiaGFuZGxlU3VibWl0IiwidHJpbW1lZENvbW1hbmQiLCJhbGVydCIsInNwbGl0Iiwic2xpY2UiLCJ0aGVuIiwiaGFuZGxlRW50ZXJQcmVzcyIsImUiLCJrZXkiLCJoYW5kbGVLZXlQcmVzcyIsImN0cmxLZXkiLCJpbnB1dEVsZW1lbnQiLCJkb2N1bWVudCIsInF1ZXJ5U2VsZWN0b3IiLCJIVE1MSW5wdXRFbGVtZW50IiwiZm9jdXMiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTElucHV0LnRzeCJdLCJmaWxlIjoiQzovVXNlcnMvcHJhbmEvRG9jdW1lbnRzL0dpdEh1Yi9tYXBzLXBybGFrc2htLXRib25hcy9tYXBzL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1JFUExJbnB1dC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcclxuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9Db250cm9sbGVkSW5wdXRcIjtcclxuaW1wb3J0IHsgSGlzdG9yeUl0ZW0gfSBmcm9tIFwiLi4vdHlwZXMvSGlzdG9yeUl0ZW1cIjtcclxuaW1wb3J0IHsgUkVQTEZ1bmN0aW9uIH0gZnJvbSBcIi4uL3R5cGVzL1JFUExGdW5jdGlvblwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuLyoqXHJcbiAqIE1hcCBzdG9yaW5nIHJlZ2lzdGVyZWQgY29tbWFuZHNcclxuICovXHJcbmNvbnN0IGNvbW1hbmRSZWdpc3RyeSA9IG5ldyBNYXA8c3RyaW5nLCBSRVBMRnVuY3Rpb24+KCk7XHJcblxyXG4vKipcclxuICogSGVscGVyIGZ1bmN0aW9uIHJlc3BvbnNpYmxlIGZvciByZWdpc3RlcmluZyBjb21tYW5kc1xyXG4gKiBAcGFyYW0ge3N0cmluZ30gY29tbWFuZCAtIFRoZSBuYW1lIG9mIHRoZSBjb21tYW5kIHRvIGJlIHJlZ2lzdGVyZWRcclxuICogQHBhcmFtIHtSRVBMRnVuY3Rpb259IGZ1bmMgLSBUaGUgZnVuY3Rpb24gdG8gYmUgZXhlY3V0ZWQgdXBvbiBjb21tYW5kIGNhbGxcclxuICovXHJcbmZ1bmN0aW9uIHJlZ2lzdGVyQ29tbWFuZChjb21tYW5kOiBzdHJpbmcsIGZ1bmM6IFJFUExGdW5jdGlvbikge1xyXG4gIGNvbW1hbmRSZWdpc3RyeS5zZXQoY29tbWFuZCwgZnVuYyk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBQcm9wcyBmb3IgdGhlIFJFUExJbnB1dFByb3BzIGNvbXBvbmVudFxyXG4gKi9cclxuaW50ZXJmYWNlIFJFUExJbnB1dFByb3BzIHtcclxuICBoaXN0b3J5OiBIaXN0b3J5SXRlbVtdO1xyXG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPEhpc3RvcnlJdGVtW10+PjtcclxuICBtb2RlOiBzdHJpbmc7XHJcbiAgc2V0TW9kZTogKG5ld01vZGU6IHN0cmluZykgPT4gdm9pZDtcclxuICBjb21tYW5kUmVzdWx0TWFwOiBNYXA8SGlzdG9yeUl0ZW0sIFtbXV0gfCBzdHJpbmc+O1xyXG4gIHVwZGF0ZUNvbW1hbmRSZXN1bHQ6IChjb21tYW5kOiBzdHJpbmcsIG91dHB1dDogW1tdXSB8IHN0cmluZykgPT4gdm9pZDtcclxuICBhcmlhTGFiZWw6IHN0cmluZztcclxuICBjb29yZGluYXRlczogbnVtYmVyW11bXTtcclxuICBzZXRDb29yZGluYXRlczogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248bnVtYmVyW11bXT4+O1xyXG59XHJcblxyXG4vKipcclxuICogUmVhY3QgY29tcG9uZW50IHJlc3BvbnNpYmxlIGZvciBoYW5kbGluZyB1c2VyIGlucHV0IGFuZCBleGVjdXRpbmcgY29tbWFuZHNcclxuICogQHBhcmFtIHtSRVBMSW5wdXRQcm9wc30gcHJvcHMgLSBUaGUgcHJvcGVydGllcyByZXF1aXJlZCBmb3IgcmVuZGVyaW5nIHRoZSBjb21wb25lbnRcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHM6IFJFUExJbnB1dFByb3BzKSB7XHJcbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XHJcbiAgY29uc3Qge1xyXG4gICAgbW9kZSxcclxuICAgIHNldE1vZGUsXHJcbiAgICBoaXN0b3J5LFxyXG4gICAgc2V0SGlzdG9yeSxcclxuICAgIGNvbW1hbmRSZXN1bHRNYXAsXHJcbiAgICB1cGRhdGVDb21tYW5kUmVzdWx0LFxyXG4gICAgYXJpYUxhYmVsLFxyXG4gICAgY29vcmRpbmF0ZXMsXHJcbiAgICBzZXRDb29yZGluYXRlcyxcclxuICB9ID0gcHJvcHM7XHJcblxyXG4gIC8qKlxyXG4gICAqIFJFUExGdW5jdGlvbiBoYW5kbGluZyB0aGUgcmVnaXN0cmF0aW9uIG9mIGEgdXNlci1zcGVjaWZpZWQgY29tbWFuZFxyXG4gICAqIEBwYXJhbSB7c3RyaW5nW119IGFyZ3MgLSBEZXRhaWxzIG9mIGEgdG8tYmUtcmVnaXN0ZXJlZCBmdW5jdGlvbiAoY29tbWFuZE5hbWUsIGZ1bmN0aW9uIGV4ZWN1dGVkIHVwb24gY29tbWFuZClcclxuICAgKi9cclxuICBjb25zdCBoYW5kbGVSZWdpc3RlcjogUkVQTEZ1bmN0aW9uID0gYXN5bmMgKFxyXG4gICAgYXJnczogc3RyaW5nW11cclxuICApOiBQcm9taXNlPHN0cmluZz4gPT4ge1xyXG4gICAgaWYgKGFyZ3MubGVuZ3RoICE9PSAyKSB7XHJcbiAgICAgIHJldHVybiBcIkludmFsaWQgdXNhZ2Ugb2YgJ3JlZ2lzdGVyJyBjb21tYW5kLiBVc2FnZTogcmVnaXN0ZXIgPGNvbW1hbmROYW1lPiA8ZnVuY3Rpb25Ub0V4ZWN1dGU+XCI7XHJcbiAgICB9XHJcbiAgICBjb25zdCBjb21tYW5kTmFtZSA9IGFyZ3NbMF07XHJcbiAgICBjb25zdCB0b0V4ZWN1dGUgPSBhcmdzWzFdO1xyXG4gICAgaWYgKGNvbW1hbmRSZWdpc3RyeS5oYXMoY29tbWFuZE5hbWUpKSB7XHJcbiAgICAgIHJldHVybiBcIkNvbW1hbmQ6IFwiICsgY29tbWFuZE5hbWUgKyBcIiBpcyBhbHJlYWR5IHJlZ2lzdGVyZWRcIjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlZ2lzdGVyQ29tbWFuZChjb21tYW5kTmFtZSwgZXZhbCh0b0V4ZWN1dGUpKTtcclxuICAgICAgcmV0dXJuIFwiQ29tbWFuZCByZWdpc3RlcmVkOiBcIiArIGNvbW1hbmROYW1lO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gIC8qKlxyXG4gICAqIEZ1bmN0aW9uIGhhbmRsaW5nIG1vZGUgY2hhbmdlcyBvZiB0aGUgUkVQTCBpbnRlcmZhY2VcclxuICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBhcmdzIC0gVGhlIG5ldyBtb2RlIHRvIHNldFxyXG4gICAqL1xyXG4gIGNvbnN0IGhhbmRsZU1vZGU6IFJFUExGdW5jdGlvbiA9IGFzeW5jIChhcmdzOiBzdHJpbmdbXSk6IFByb21pc2U8c3RyaW5nPiA9PiB7XHJcbiAgICBjb25zdCB2YWxpZE1vZGVzID0gW1wiYnJpZWZcIiwgXCJ2ZXJib3NlXCJdO1xyXG4gICAgaWYgKGFyZ3MubGVuZ3RoICE9PSAxKSB7XHJcbiAgICAgIHJldHVybiBcIkludmFsaWQgdXNhZ2Ugb2YgJ21vZGUnIGNvbW1hbmQuIFVzYWdlOiBtb2RlIDxuZXdNb2RlPlwiO1xyXG4gICAgfVxyXG4gICAgaWYgKHZhbGlkTW9kZXMuaW5jbHVkZXMoYXJnc1swXSkpIHtcclxuICAgICAgc2V0TW9kZShhcmdzWzBdKTtcclxuICAgICAgcmV0dXJuIFwiTW9kZSBjaGFuZ2VkIHRvIFwiICsgYXJnc1swXTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBcIkludmFsaWQgbW9kZTogXCIgKyBhcmdzWzBdICsgXCIuIFVzZSBicmllZiBvciB2ZXJib3NlXCI7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLyoqXHJcbiAgICogRnVuY3Rpb24gaGFuZGxpbmcgbG9hZGluZyB0aGUgZmlsZVxyXG4gICAqIEBwYXJhbSB7c3RyaW5nW119IGFyZ3MgLSBUaGUgZmlsZSBwYXRoIG9mIGEgZmlsZSB0byBiZSBsb2FkZWQgKG11c3QgYmUgd2l0aGluIHRoZSBkYXRhIGRpcmVjdG9yeSlcclxuICAgKi9cclxuICBjb25zdCBoYW5kbGVMb2FkOiBSRVBMRnVuY3Rpb24gPSBhc3luYyAoYXJnczogc3RyaW5nW10pOiBQcm9taXNlPHN0cmluZz4gPT4ge1xyXG4gICAgaWYgKGFyZ3MubGVuZ3RoICE9PSAxKSB7XHJcbiAgICAgIHJldHVybiBcIkludmFsaWQgdXNhZ2Ugb2YgJ2xvYWQnIGNvbW1hbmQuIFVzYWdlOiBsb2FkIDxVUkw+XCI7XHJcbiAgICB9XHJcbiAgICBjb25zdCBmaWxlcGF0aCA9IGFyZ3NbMF0udHJpbSgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICBgaHR0cDovL2xvY2FsaG9zdDo0MDAwL2xvYWRjc3Y/ZmlsZXBhdGg9JHtmaWxlcGF0aH1gXHJcbiAgICAgICk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5vaykge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0TWVzc2FnZSA9XHJcbiAgICAgICAgICBkYXRhLnJlc3VsdCA9PT0gXCJzdWNjZXNzXCJcclxuICAgICAgICAgICAgPyBcIkZpbGUgXCIgKyBmaWxlcGF0aCArIFwiIGxvYWRlZCBzdWNjZXNzZnVsbHlcIlxyXG4gICAgICAgICAgICA6IGRhdGEuZXJyb3JfbWVzc2FnZTtcclxuICAgICAgICByZXR1cm4gcmVzdWx0TWVzc2FnZTtcclxuICAgICAgfSBlbHNlIHJldHVybiBcIkZhaWxlZCB0byBmZXRjaCBkYXRhIGZyb20gdGhlIGJhY2tlbmRcIjtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIC8vIEltcGxlbWVudCB0aGUgbG9naWMgdG8gbG9hZCB0aGUgZmlsZSBiYXNlZCBvbiB0aGUgcHJvdmlkZWQgJ3VybCcuXHJcbiAgICAgIC8vIFJldHVybiBhbiBhcHByb3ByaWF0ZSByZXN1bHQgbWVzc2FnZS5cclxuICAgICAgcmV0dXJuIFwiQW4gZXJyb3Igb2N1cnJlZCB3aGlsZSBsb2FkaW5nIHRoZSBmaWxlOiBcIiArIGVycm9yO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8qKlxyXG4gICAqIEZ1bmN0aW9uIGhhbmRsaW5nIHZpZXdpbmcgdGhlIGxvYWRlZCBkYXRhc2V0XHJcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gYXJncyAtIE5vbmUgKGVtcHR5KVxyXG4gICAqL1xyXG4gIGNvbnN0IGhhbmRsZVZpZXc6IFJFUExGdW5jdGlvbiA9IGFzeW5jIChhcmdzOiBzdHJpbmdbXSk6IFByb21pc2U8c3RyaW5nPiA9PiB7XHJcbiAgICBpZiAoYXJncy5sZW5ndGggIT09IDApIHtcclxuICAgICAgcmV0dXJuIFwiSW52YWxpZCB1c2FnZSBvZiAndmlldycgY29tbWFuZC4gVXNhZ2U6IHZpZXdcIjtcclxuICAgIH1cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXCJodHRwOi8vbG9jYWxob3N0OjQwMDAvdmlld2NzdlwiKTtcclxuICAgICAgaWYgKHJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgICBjb25zdCByZXN1bHRNZXNzYWdlID1cclxuICAgICAgICAgIGRhdGEucmVzdWx0ID09PSBcInN1Y2Nlc3NcIiA/IGRhdGEuZGF0YSA6IGRhdGEuZXJyb3JfbWVzc2FnZTtcclxuICAgICAgICByZXR1cm4gcmVzdWx0TWVzc2FnZTtcclxuICAgICAgfSBlbHNlIHJldHVybiBcIkZhaWxlZCB0byBmZXRjaCBkYXRhIGZyb20gdGhlIGJhY2tlbmRcIjtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiBcIkFuIGVycm9yIG9jY3VycmVkIHdoaWxlIHZpZXdpbmcgdGhlIGZpbGU6IFwiICsgZXJyb3I7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLyoqXHJcbiAgICogRnVuY3Rpb24gaGFuZGxpbmcgc2VhcmNoaW5nIHdpdGhpbiB0aGUgbG9hZGVkIGRhdGFzZXRcclxuICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBhcmdzIC0gVGhlIHNlYXJjaCBxdWVyeSBwYXJhbWV0ZXJzXHJcbiAgICovXHJcbiAgY29uc3QgaGFuZGxlU2VhcmNoOiBSRVBMRnVuY3Rpb24gPSBhc3luYyAoXHJcbiAgICBhcmdzOiBzdHJpbmdbXVxyXG4gICk6IFByb21pc2U8c3RyaW5nPiA9PiB7XHJcbiAgICBpZiAoYXJncy5sZW5ndGggIT09IDMpIHtcclxuICAgICAgcmV0dXJuIFwiSW52YWxpZCBzZWFyY2ggY29tbWFuZC4gVXNhZ2U6IHNlYXJjaCA8aGFzSGVhZGVycz4gPHZhbHVlPiA8Y29sdW1uSWQ+XCI7XHJcbiAgICB9XHJcbiAgICBjb25zdCBoYXNIZWFkZXJzID0gYXJnc1swXTtcclxuICAgIGNvbnN0IHZhbHVlID0gYXJnc1sxXS5pbmNsdWRlcyhcIiVcIilcclxuICAgICAgPyBhcmdzWzFdLnJlcGxhY2UoXCIlXCIsIFwiJTI1XCIpLnJlcGxhY2UoL18vZywgXCIgXCIpXHJcbiAgICAgIDogYXJnc1sxXS5yZXBsYWNlKC9fL2csIFwiIFwiKTtcclxuICAgIGNvbnN0IGNvbHVtbklkID0gYXJnc1syXS5yZXBsYWNlKC9fL2csIFwiIFwiKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgIGBodHRwOi8vbG9jYWxob3N0OjQwMDAvc2VhcmNoY3N2P2hlYWRlcnM9JHtoYXNIZWFkZXJzfSZ2YWx1ZT0ke3ZhbHVlfSZjb2xpZD0ke2NvbHVtbklkfWBcclxuICAgICAgKTtcclxuICAgICAgaWYgKHJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgICBjb25zdCByZXN1bHRNZXNzYWdlID1cclxuICAgICAgICAgIGRhdGEucmVzdWx0ID09PSBcInN1Y2Nlc3NcIiA/IGRhdGEuZGF0YSA6IGRhdGEuZXJyb3JfbWVzc2FnZTtcclxuICAgICAgICByZXR1cm4gcmVzdWx0TWVzc2FnZTtcclxuICAgICAgfSBlbHNlIHJldHVybiBcIkZhaWxlZCB0byBmZXRjaCBkYXRhIGZyb20gdGhlIGJhY2tlbmRcIjtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiBcIkFuIGVycm9yIG9jY3VycmVkIHdoaWxlIHNlYXJjaGluZyB0aHJvdWdoIHRoZSBmaWxlOiBcIiArIGVycm9yO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8qKlxyXG4gICAqIEZ1bmN0aW9uIGhhbmRsaW5nIHJldHJpZXZpbmcgYnJvYWRiYW5kIGFjY2VzcyBwZXJjZW50YWdlXHJcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gYXJncyAtIFRoZSBicm9hZGJhbmQgcXVlcnkgcGFyYW1ldGVyc1xyXG4gICAqL1xyXG4gIGNvbnN0IGhhbmRsZUJyb2FkYmFuZDogUkVQTEZ1bmN0aW9uID0gYXN5bmMgKFxyXG4gICAgYXJnczogc3RyaW5nW11cclxuICApOiBQcm9taXNlPHN0cmluZz4gPT4ge1xyXG4gICAgaWYgKGFyZ3MubGVuZ3RoICE9PSAyKSB7XHJcbiAgICAgIHJldHVybiBcIkludmFsaWQgYnJvYWRiYW5kIHJldHJpZXZhbCBjb21tYW5kLiBVc2FnZTogYnJvYWRiYW5kIDxzdGF0ZT4gPGNvdW50eT5cIjtcclxuICAgIH1cclxuICAgIGNvbnN0IHN0YXRlID0gYXJnc1swXS5yZXBsYWNlKC9fL2csIFwiIFwiKTtcclxuICAgIGNvbnN0IGNvdW50eSA9IGFyZ3NbMV0ucmVwbGFjZSgvXy9nLCBcIiBcIik7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICBgaHR0cDovL2xvY2FsaG9zdDo0MDAwL2Jyb2FkYmFuZD9zdGF0ZT0ke3N0YXRlfSZjb3VudHk9JHtjb3VudHl9YFxyXG4gICAgICApO1xyXG4gICAgICBpZiAocmVzcG9uc2Uub2spIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdE1lc3NhZ2UgPVxyXG4gICAgICAgICAgZGF0YS5yZXN1bHQgPT09IFwic3VjY2Vzc1wiXHJcbiAgICAgICAgICAgID8gYHRpbWUgb2YgcmV0cmlldmFsOiAke2RhdGEuZGF0ZV90aW1lfSBicm9hZGJhbmQgYWNjZXNzIHBlcmNlbnQ6ICR7ZGF0YS5icm9hZGJhbmRfYWNjZXNzX3BlcmNlbnR9YFxyXG4gICAgICAgICAgICA6IGRhdGEuZXJyb3JfbWVzc2FnZTtcclxuICAgICAgICByZXR1cm4gcmVzdWx0TWVzc2FnZTtcclxuICAgICAgfSBlbHNlIHJldHVybiBcIkZhaWxlZCB0byBmZXRjaCBkYXRhIGZyb20gdGhlIGJhY2tlbmRcIjtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiBcIkFuIGVycm9yIG9jY3VycmVkIHdoaWxlIGZldGNoaW5nIGJyb2FkYmFuZCBkYXRhOiBcIiArIGVycm9yO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8qKlxyXG4gICAqIEZ1bmN0aW9uIGhhbmRsaW5nIHNlYXJjaCBhcmVhcyBmb3IgaGlnaGxpZ2h0aW5nIG1hcFxyXG4gICAqIEBwYXJhbSB7c3RyaW5nW119IGFyZ3MgLSBrZXl3b3JkIHRvIHNlYXJjaCBhcmVhc1xyXG4gICAqL1xyXG4gIGNvbnN0IGhhbmRsZUFyZWFzOiBSRVBMRnVuY3Rpb24gPSBhc3luYyAoYXJnczogc3RyaW5nW10pOiBQcm9taXNlPHN0cmluZz4gPT4ge1xyXG4gICAgaWYgKGFyZ3MubGVuZ3RoICE9PSAxKSB7XHJcbiAgICAgIHJldHVybiBcIkludmFsaWQgdXNhZ2Ugb2YgJ3NlYXJjaGFyZWFzJyBjb21tYW5kLiBVc2FnZTogc2VhcmNoYXJlYXMgPGtleXdvcmQ+XCI7XHJcbiAgICB9XHJcbiAgICBjb25zdCBrZXl3b3JkID0gYXJnc1swXS50cmltKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgIGBodHRwOi8vbG9jYWxob3N0OjQwMDAvc2VhcmNoYXJlYXM/a2V5d29yZD0ke2tleXdvcmR9YFxyXG4gICAgICApO1xyXG4gICAgICBpZiAocmVzcG9uc2Uub2spIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gICAgICAgIHNldENvb3JkaW5hdGVzKGRhdGEuY29vcmRpbmF0ZXNMaXN0KTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0TWVzc2FnZSA9XHJcbiAgICAgICAgICBkYXRhLnJlc3VsdCA9PT0gXCJzdWNjZXNzXCJcclxuICAgICAgICAgICAgPyBcIkFyZWFzIGRlc2NyaXB0aW9ucyB3aXRoIFwiICsga2V5d29yZCArIFwiIGhpZ2hsaWdodGVkIHN1Y2Nlc3NmdWxseVwiXHJcbiAgICAgICAgICAgIDogZGF0YS5lcnJvcl9tZXNzYWdlO1xyXG4gICAgICAgIHJldHVybiByZXN1bHRNZXNzYWdlO1xyXG4gICAgICB9IGVsc2UgcmV0dXJuIFwiRmFpbGVkIHRvIGZldGNoIGFyZWFzIGZyb20gdGhlIGJhY2tlbmRcIjtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIC8vIFJldHVybiBhbiBhcHByb3ByaWF0ZSByZXN1bHQgbWVzc2FnZS5cclxuICAgICAgcmV0dXJuIFwiQW4gZXJyb3Igb2N1cnJlZCB3aGlsZSBzZWFyY2hpbmcgZm9yIGFyZWFzOiBcIiArIGVycm9yO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgLyoqXHJcbiAgICogRnVuY3Rpb25zIHJlZ2lzdGVyZWQgdXBvbiBjb21wb25lbnQgbW91bnRcclxuICAgKi9cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgcmVnaXN0ZXJDb21tYW5kKFwicmVnaXN0ZXJcIiwgaGFuZGxlUmVnaXN0ZXIpO1xyXG4gICAgcmVnaXN0ZXJDb21tYW5kKFwibW9kZVwiLCBoYW5kbGVNb2RlKTtcclxuICAgIHJlZ2lzdGVyQ29tbWFuZChcImxvYWRcIiwgaGFuZGxlTG9hZCk7XHJcbiAgICByZWdpc3RlckNvbW1hbmQoXCJ2aWV3XCIsIGhhbmRsZVZpZXcpO1xyXG4gICAgcmVnaXN0ZXJDb21tYW5kKFwic2VhcmNoXCIsIGhhbmRsZVNlYXJjaCk7XHJcbiAgICByZWdpc3RlckNvbW1hbmQoXCJicm9hZGJhbmRcIiwgaGFuZGxlQnJvYWRiYW5kKTtcclxuICAgIHJlZ2lzdGVyQ29tbWFuZChcInNlYXJjaGFyZWFzXCIsIGhhbmRsZUFyZWFzKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIEhlbHBlciBmdW5jdGlvbiBmb3IgZXhlY3V0aW5nIHRoZSBjb21tYW5kIHVwb24gaW5wdXQgc3VibWlzc2lvblxyXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBjb21tYW5kTmFtZSAtIE5hbWUgb2YgdGhlIGNvbW1hbmRcclxuICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBhcmdzIC0gQXJndW1lbnRzIGZvciB0aGUgdG8tYmUtZXhlY3V0ZWQgZnVuY3Rpb24gYXNzaWduZWQgdG8gdGhlIGNvbW1hbmRcclxuICAgKi9cclxuICBhc3luYyBmdW5jdGlvbiBleGVjdXRlQ29tbWFuZChcclxuICAgIGNvbW1hbmROYW1lOiBzdHJpbmcsXHJcbiAgICBhcmdzOiBzdHJpbmdbXVxyXG4gICk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgICBjb25zdCBmdW5jID0gY29tbWFuZFJlZ2lzdHJ5LmdldChjb21tYW5kTmFtZSk7XHJcblxyXG4gICAgaWYgKGZ1bmMpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBFeGVjdXRlIHRoZSByZWdpc3RlcmVkIGZ1bmN0aW9uIGFuZCBwYXNzIHRoZSBhcmd1bWVudHMsIGV4Y2x1ZGluZyB0aGUgY29tbWFuZCBpdHNlbGZcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmdW5jKGFyZ3MpO1xyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgcmV0dXJuIGBFcnJvciBleGVjdXRpbmcgY29tbWFuZC4gJHtlcnJvcn1gO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gYENvbW1hbmQgbm90IGZvdW5kOiAke2NvbW1hbmROYW1lfS4gSW5wdXQgXCJyZWdpc3RlciA8Y29tbWFuZE5hbWU+IDxmdW5jdGlvbj5cIiB0byByZWdpc3RlciBuZXcgY29tbWFuZGA7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBGdW5jdGlvbiB0cmlnZ2VyZWQgd2hlbiB0aGUgXCJTdWJtaXRcIiBidXR0b24gaXMgY2xpY2tlZCB0byBwcm9jZXNzIHRoZSB1c2VyJ3MgY29tbWFuZFxyXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBjb21tYW5kU3RyaW5nIC0gVGhlIHdob2xlIHVzZXIgaW5wdXRcclxuICAgKi9cclxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XHJcbiAgICBjb25zdCB0cmltbWVkQ29tbWFuZCA9IGNvbW1hbmRTdHJpbmcudHJpbSgpO1xyXG4gICAgaWYgKHRyaW1tZWRDb21tYW5kID09PSBcIlwiKSB7XHJcbiAgICAgIGFsZXJ0KFwiQ29tbWFuZCBjYW5ub3QgYmUgZW1wdHlcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBhcnJheSBvZiBhbGwgd29yZHMgZW50ZXJlZCBieSB1c2VyIGluIHRoZSBjb21tYW5kIGlucHV0XHJcbiAgICBjb25zdCBhcmdzID0gdHJpbW1lZENvbW1hbmQuc3BsaXQoL1xccysvKTtcclxuICAgIC8vIGFyZ3NbMF0gaXMgdGhlIGNvbW1hbmQgbmFtZSwgYXJncy5zbGljZSgxKSBpcyBhbiBhcnJheSBvZiBldmVyeXRoaW5nIEVYQ0VQVCBmb3IgdGhlIGNvbW1hbmQgbmFtZVxyXG4gICAgZXhlY3V0ZUNvbW1hbmQoYXJnc1swXSwgYXJncy5zbGljZSgxKSkudGhlbigocmVzdWx0KSA9PiB7XHJcbiAgICAgIHVwZGF0ZUNvbW1hbmRSZXN1bHQoY29tbWFuZFN0cmluZywgcmVzdWx0KTtcclxuICAgICAgc2V0Q291bnQoY291bnQgKyAxKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XHJcbiAgfVxyXG5cclxuICAvL0FsbCBrZXlib2FyZCBzaG9ydGN1dHMgaGVyZVxyXG4gIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgLyoqXHJcbiAgICogSGFuZGxlcyBrZXlib2FyZCBzaG9ydGN1dCB0byBzdWJtaXQgYnkgcHJlc3NpbmcgRW50ZXIgaW4gY29tbWFuZCBib3hcclxuICAgKiBAcGFyYW0gZSBrZXlib2FyZCBldmVudCBvZiBwcmVzc2luZyBFbnRlciBrZXlcclxuICAgKi9cclxuICBmdW5jdGlvbiBoYW5kbGVFbnRlclByZXNzKGU6IFJlYWN0LktleWJvYXJkRXZlbnQpIHtcclxuICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XHJcbiAgICAgIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFdlYnBhZ2UgYWx3YXlzIGxpc3RlbnMgb3V0IGZvciBDdHJsK2IgdG8gbmF2aWdhdGUgY3Vyc29yIHRvIGNvbW1hbmQgYm94XHJcbiAgICovXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGhhbmRsZUtleVByZXNzID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcclxuICAgICAgaWYgKGUua2V5ID09PSBcImJcIiAmJiBlLmN0cmxLZXkpIHtcclxuICAgICAgICBjb25zdCBpbnB1dEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnJlcGwtY29tbWFuZC1ib3hcIik7XHJcbiAgICAgICAgaWYgKGlucHV0RWxlbWVudCAmJiBpbnB1dEVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KVxyXG4gICAgICAgICAgaW5wdXRFbGVtZW50LmZvY3VzKCk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlS2V5UHJlc3MpO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleVByZXNzKTtcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCIgYXJpYS1saXZlPVwicG9saXRlXCIgYXJpYS1sYWJlbD17YXJpYUxhYmVsfT5cclxuICAgICAgPGZpZWxkc2V0PlxyXG4gICAgICAgIDxsZWdlbmQ+RW50ZXIgYSBjb21tYW5kOjwvbGVnZW5kPlxyXG4gICAgICAgIDxDb250cm9sbGVkSW5wdXRcclxuICAgICAgICAgIHZhbHVlPXtjb21tYW5kU3RyaW5nfVxyXG4gICAgICAgICAgc2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9XHJcbiAgICAgICAgICBhcmlhTGFiZWw9e1wiQ29tbWFuZCBJbnB1dCBCb3ggdG8gdHlwZSBpbiBjb21tYW5kc1wifVxyXG4gICAgICAgICAgb25LZXlEb3duPXtoYW5kbGVFbnRlclByZXNzfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZmllbGRzZXQ+XHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICBhcmlhLWxhYmVsPVwicmVwbC1pbnB1dC1zdWJtaXQtYnV0dG9uXCJcclxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyl9XHJcbiAgICAgID5cclxuICAgICAgICBTdWJtaXRcclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==