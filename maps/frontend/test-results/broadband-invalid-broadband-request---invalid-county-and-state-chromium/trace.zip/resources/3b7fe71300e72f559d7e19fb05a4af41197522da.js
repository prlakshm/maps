import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ControlledInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css?t=1699714527458";
export function ControlledInput({
  value,
  // The current value of the input.
  setValue,
  // A function to update the input's value.
  onKeyDown,
  // An optional function to handle keydown events.
  ariaLabel
  // A text label for accessibility purposes.
}) {
  return /* @__PURE__ */ jsxDEV(
    "input",
    {
      type: "text",
      className: "repl-command-box",
      value,
      placeholder: "Enter command here!",
      onChange: (ev) => setValue(ev.target.value),
      onKeyDown,
      "aria-label": ariaLabel
    },
    void 0,
    false,
    {
      fileName: "C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/ControlledInput.tsx",
      lineNumber: 28,
      columnNumber: 10
    },
    this
  );
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/prana/Documents/GitHub/maps-prlakshm-tbonas/maps/frontend/src/components/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJJO0FBNUJKLE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXFCcEIsZ0JBQVNBLGdCQUFnQjtBQUFBLEVBQzlCQztBQUFBQTtBQUFBQSxFQUNBQztBQUFBQTtBQUFBQSxFQUNBQztBQUFBQTtBQUFBQSxFQUNBQztBQUFBQTtBQUNvQixHQUFHO0FBQ3ZCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMLFdBQVU7QUFBQSxNQUNWO0FBQUEsTUFDQSxhQUFZO0FBQUEsTUFDWixVQUFXQyxRQUFPSCxTQUFTRyxHQUFHQyxPQUFPTCxLQUFLO0FBQUEsTUFDMUM7QUFBQSxNQUNBLGNBQVlHO0FBQUFBO0FBQUFBLElBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUM7QUFFTDtBQUFDRyxLQWpCZVA7QUFBZTtBQUFBUSIsIm5hbWVzIjpbIkNvbnRyb2xsZWRJbnB1dCIsInZhbHVlIiwic2V0VmFsdWUiLCJvbktleURvd24iLCJhcmlhTGFiZWwiLCJldiIsInRhcmdldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udHJvbGxlZElucHV0LnRzeCJdLCJmaWxlIjoiQzovVXNlcnMvcHJhbmEvRG9jdW1lbnRzL0dpdEh1Yi9tYXBzLXBybGFrc2htLXRib25hcy9tYXBzL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0NvbnRyb2xsZWRJbnB1dC50c3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcclxuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcblxyXG4vKipcclxuICogUHJvcHMgZm9yIHRoZSBDb250cm9sbGVkSW5wdXQgY29tcG9uZW50LlxyXG4gKi9cclxuaW50ZXJmYWNlIENvbnRyb2xsZWRJbnB1dFByb3BzIHtcclxuICB2YWx1ZTogc3RyaW5nOyAvLyBUaGUgY3VycmVudCB2YWx1ZSBvZiB0aGUgaW5wdXQuXHJcbiAgc2V0VmFsdWU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+OyAvLyBBIGZ1bmN0aW9uIHRvIHVwZGF0ZSB0aGUgaW5wdXQncyB2YWx1ZS5cclxuICBhcmlhTGFiZWw6IHN0cmluZzsgLy8gQSB0ZXh0IGxhYmVsIGZvciBhY2Nlc3NpYmlsaXR5IHB1cnBvc2VzLlxyXG4gIG9uS2V5RG93bj86IChlOiBSZWFjdC5LZXlib2FyZEV2ZW50KSA9PiB2b2lkOyAvL25ldyBvcHRpb25hbCBwcm9wIHRvIGhhbmRsZSBwcmVzc2luZyBzdWJtaXQgZnJvbSBjb250cm9sbGVkIGlucHV0XHJcbn1cclxuXHJcblxyXG5cclxuLyoqXHJcbiAqIEEgY29udHJvbGxlZCBpbnB1dCBjb21wb25lbnQgY29ycmVzcG9uZGluZyB0byB1c2VyJ3MgaW5wdXQgaW4gdGhlIGNvbW1hbmQgYm94LlxyXG4gKiBBbGxvd3MgZm9yIGl0cyB2YWx1ZSB0byBiZSBtYW5hZ2VkIGV4dGVybmFsbHkuXHJcbiAqIEBwYXJhbSB7Q29udHJvbGxlZElucHV0UHJvcHN9IHByb3BzIC0gVGhlIHByb3BzIGZvciB0aGUgQ29udHJvbGxlZElucHV0IGNvbXBvbmVudC5cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBDb250cm9sbGVkSW5wdXQoe1xyXG4gIHZhbHVlLCAvLyBUaGUgY3VycmVudCB2YWx1ZSBvZiB0aGUgaW5wdXQuXHJcbiAgc2V0VmFsdWUsIC8vIEEgZnVuY3Rpb24gdG8gdXBkYXRlIHRoZSBpbnB1dCdzIHZhbHVlLlxyXG4gIG9uS2V5RG93biwgLy8gQW4gb3B0aW9uYWwgZnVuY3Rpb24gdG8gaGFuZGxlIGtleWRvd24gZXZlbnRzLlxyXG4gIGFyaWFMYWJlbCwgLy8gQSB0ZXh0IGxhYmVsIGZvciBhY2Nlc3NpYmlsaXR5IHB1cnBvc2VzLlxyXG59OiBDb250cm9sbGVkSW5wdXRQcm9wcykge1xyXG4gIHJldHVybiAoXHJcbiAgICA8aW5wdXRcclxuICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICBjbGFzc05hbWU9XCJyZXBsLWNvbW1hbmQtYm94XCJcclxuICAgICAgdmFsdWU9e3ZhbHVlfSAvLyBCaW5kIHRoZSBpbnB1dCdzIHZhbHVlIHRvIHRoZSBwcm92aWRlZCAndmFsdWUnIHByb3AuXHJcbiAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgY29tbWFuZCBoZXJlIVwiXHJcbiAgICAgIG9uQ2hhbmdlPXsoZXYpID0+IHNldFZhbHVlKGV2LnRhcmdldC52YWx1ZSl9IC8vIFVwZGF0ZSB0aGUgaW5wdXQncyB2YWx1ZSB3aGVuIGl0IGNoYW5nZXMuXHJcbiAgICAgIG9uS2V5RG93bj17b25LZXlEb3dufSAvLyBIYW5kbGUga2V5ZG93biBldmVudHMgaWYgdGhlICdvbktleURvd24nIHByb3AgaXMgcHJvdmlkZWQuXHJcbiAgICAgIGFyaWEtbGFiZWw9e2FyaWFMYWJlbH0gLy8gU2V0IHRoZSBhY2Nlc3NpYmlsaXR5IGxhYmVsIGZvciBzY3JlZW4gcmVhZGVycy5cclxuICAgID48L2lucHV0PlxyXG4gICk7XHJcbn1cclxuIl19